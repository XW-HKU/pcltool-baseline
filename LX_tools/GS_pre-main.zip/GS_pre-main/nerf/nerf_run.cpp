#include "nerf_pre.h"

int main (int argc, char** argv)
{
    NERF_PRE nerf_pre;
    std::string inputDir;
    bool need_undistort;
    float downsample_size;
    if (argc > 1)
    {
        inputDir = argv[1];
        need_undistort = (argv[2][0] == '1');
        // downsample_size = argv[2][1];
        // get third argument as a float for downsample size
        downsample_size = atof(argv[3]);
    }
    else
    {
        printf("need directory\n", argv[0]);
    }
    nerf_pre.run(inputDir, need_undistort, downsample_size);
}