#ifndef NERF_OUT_H
#define NERF_OUT_H

#include <iostream>
#include <time.h>
#include <thread>
#include <fstream>
#include <map>
#include <unordered_map>

namespace COLMAP_IN
{
    enum CAMTYPE
    {
        FISH_EYE = 0,
        PINHOLE = 1
    };

    struct CAM_T
    {
        Eigen::Matrix4d T_fish[2];
        Eigen::Matrix4d T_pinhole[4];
    };

    struct KEYPOINT2D
    {
        float u;
        float v;
        unsigned int point3D_id;
        
        KEYPOINT2D(float u, float v, unsigned int pt_id)
        {
            this->u = u;
            this->v = v;
            this->point3D_id = pt_id;
        };
    };

    struct FRAME
    {
        CAMTYPE type;
        unsigned int cam_id;
        Eigen::Matrix4d T;
        std::vector<KEYPOINT2D> keypoint_list;
        FRAME(Eigen::Matrix4d & Tin) : T(Tin) {};
        FRAME(CAMTYPE typein, unsigned int camid, Eigen::Matrix4d & Tin): type(typein), cam_id(camid), T(Tin) {};
    };
}

#endif