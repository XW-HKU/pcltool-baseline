#include "off_render.h"
#include "tinyxml.h"
#include "nerf_out.h"
// #include "tinystr.h"
#include <boost/filesystem.hpp>
#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>
#include <Eigen/Eigen>
#include <fstream>
#include <iostream>
#include <math.h>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <string.h>
#include <filesystem>
#include <pcl/filters/statistical_outlier_removal.h>




// #include "open3d/Open3D.h"
// #include "open3d/io/PointCloudIO.h"
// #include "open3d/visualization/utility/DrawGeometry.h"
// #include "open3d/geometry/PointCloud.h"
// #include "open3d/geometry/TriangleMesh.h"

#include "lx_tools.h"



// 载入Section参数
// void loadSectionParams(std::string & filename, std::vector<Eigen::Matrix4d>& cam_pose)
// {
//     // 解析img_pos.txt文件，将数据存储到相机位置映射中
//     std::ifstream camera_pos_file(filename);
//     if (camera_pos_file.is_open())
//     {
//         int index;
//         float t, x, y, z, q0, q1, q2, q3;
//         while (camera_pos_file >> index >> t >> x >> y >> z >> q0 >> q1 >> q2 >> q3)
//         {
//             Eigen::Matrix4d T;
//             T << 1 - 2 * q2 * q2 - 2 * q3 * q3, 2 * q1 * q2 - 2 * q0 * q3, 2 * q1 * q3 + 2 * q0 * q2, x,
//                 2 * q1 * q2 + 2 * q0 * q3, 1 - 2 * q1 * q1 - 2 * q3 * q3, 2 * q2 * q3 - 2 * q0 * q1, y,
//                 2 * q1 * q3 - 2 * q0 * q2, 2 * q2 * q3 + 2 * q0 * q1, 1 - 2 * q1 * q1 - 2 * q2 * q2, z,
//                 0, 0, 0, 1;
//             cam_pose.push_back(T);
//         }
//         camera_pos_file.close();
//     }
//     else
//     {
//         // ccLog::Warning("[LxFilter] Unable to open img_pos.txt file");
//         printf("Unable to open img_pos file: %s \n", filename.c_str());
//     }

//     // print cam_pose of each index
//     for (auto it = cam_pose.begin(); it != cam_pose.end(); ++it)
//     {
//         // std::cout << "index: " << it->first << " t: " << std::get<0>(it->second) << " T: " << std::endl << std::get<1>(it->second) << std::endl;
//     }
// }



// 载入Section图像
void OfflineRender::loadSectionImage(std::string image_path,
                      std::map<int, cv::Mat>& left_images,
                      std::map<int, cv::Mat>& right_images)
{
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir(image_path.c_str())) != NULL)
    {
        printf("image_path: %s\n", image_path.c_str());
        while ((ent = readdir(dir)) != NULL)
        {
            std::string filename = ent->d_name;

            // 检查文件名长度是否大于6
            if (filename.size() > 6) {
                std::string ext = filename.substr(filename.size() - 5);
                std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);

                if (ext == ".jpeg")
                {
                    int camera_index = std::stoi(filename.substr(3, 1));
                    cv::Mat image = cv::imread(image_path + "/" + filename);
                    int  pic_index = std::stoi(filename.substr(filename.find("_") + 1, filename.find(".") - filename.find("_") - 1));

                    if (camera_index == 0)
                    {
                        left_images[pic_index] = image;
                    }
                    else if (camera_index == 1)
                    {
                        right_images[pic_index] = image;
                    }
                    else
                    {
                        std::cerr << "Error: Invalid image file: " << filename << std::endl;
                    }
                }
            }
        }
        closedir(dir);
    }
    else
    {
        std::cerr << "Error: Unable to open directory: " << image_path << std::endl;
    }
}

void OfflineRender::showPointCloud(pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cloud)
{
    pcl::visualization::PCLVisualizer::Ptr viewer(new pcl::visualization::PCLVisualizer("3D Viewer"));
    viewer->setBackgroundColor(0, 0, 0);
    viewer->addPointCloud<pcl::PointXYZRGBL>(cloud, "sample cloud");
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "sample cloud");
    viewer->addCoordinateSystem(1.0);
    viewer->initCameraParameters();
    while (!viewer->wasStopped())
    {
        viewer->spinOnce(100);
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        // viewer->updatePointCloud<pcl::PointXYZRGBL>(cloud, "sample cloud");
    }
}

void OfflineRender::reprojectpt(const pcl::PointXYZRGBL & point, 
                    cv::Mat& image0, 
                    cv::Mat& image1,
                    Eigen::Matrix4d T_w_i,
                    CamParams<double> cam_params,
                    pcl::PointXYZRGBL & reprojected_point)
{
    // pcl::PointXYZRGBL reprojected_point;
    pcl::PointXYZRGBL reprojected_point_left;
    pcl::PointXYZRGBL reprojected_point_right;

    Eigen::Vector2d uv_left, uv_right;
    double max_ang = 200. / 180. * 3.1415926;  // 设置最大角度，根据实际情况进行调整
    double max_ang_cos = cos(max_ang);
    double ang_mix_thr = 80. / 180. * 3.1415926;  // 设置混合角度，根据实际情况进行调整
    double ang_mix_thr_cos = cos(ang_mix_thr);
    
    // 雷达到imu的外参
    static Eigen::Matrix4d T_i_l = Eigen::Matrix4d::Identity(); 
    T_i_l << 1, 0, 0, -0.011,
             0, 1, 0, -0.02329,
             0, 0, 1, 0.04412,
             0, 0, 0, 1;

    // T_w_i * T_i_l 的逆
    Eigen::Matrix4d T_reverse = (T_w_i * T_i_l).inverse();

    // 确保至少有一个相机参数集
    if (cam_params.inner_list.empty() || cam_params.ext_list.empty())
    {
        std::cerr << "No camera parameters found." << std::endl;
        return;
    }   
    // 左相机参数集
    const poly_inner<double>& inner0 = cam_params.inner_list[0];
    Eigen::Matrix<double, 4, 4> T_left = cam_params.ext_list[0].Tcl * T_reverse;
    // 右相机参数集
    const poly_inner<double>& inner1 = cam_params.inner_list[1];
    Eigen::Matrix<double, 4, 4> T_right = cam_params.ext_list[1].Tcl * T_reverse;


    

    // 遍历体素中的所有点，并投影到图像平面上
    // reprojected_points.reserve(voxel_points.size());
    
    // static int jj = 0; if (jj++ % 1000 == 0) printf("rendering point in a voxel [%f, %f, %f] with size %d\n", voxel_points[0].x, voxel_points[0].y, voxel_points[0].z, voxel_points.size());

    Eigen::Matrix<double, 3, 1> p_l(point.x, point.y, point.z);
    // double p_l_norm = p_l.norm();
    // Eigen::Matrix<double, 3, 1> p_c = T_left.block<3, 3>(0, 0) * p_l + T_left.block<3, 1>(0, 3);
    // double theta_l_cos = p_c(2) / p_l_norm;
    // p_c = T_right.block<3, 3>(0, 0) * p_l + T_right.block<3, 1>(0, 3);
    // double theta_r_cos = p_c(2) / p_l_norm;
    Proj2DAng<double> p_2DAng, p_2DAng0, p_2DAng1;
    int x, y;
    cv::Vec3b color;

    // 先做投影，在做后续处理
    reprojected_point = point;

    PolyProject poly_project;
    int ret0 = poly_project.point_project(p_l, T_left,  inner0, max_ang, p_2DAng0);
    int ret1 = poly_project.point_project(p_l, T_right, inner1, max_ang, p_2DAng1);
    // if (ret0 == IN_IMG || ret1 = IN_IMG ) // 成功投影
    // {
    //     // 左相机上色
    //     // 从图像中获取对应像素的RGB值
    //     int x = static_cast<int>(p_2DAng0.p_2(0));
    //     int y = static_cast<int>(p_2DAng0.p_2(1));
    //     cv::Vec3b color = image0.at<cv::Vec3b>(y, x);

    //     // 将投影点的颜色设置为对应像素的颜色
    //     reprojected_point_left.r = color[2];
    //     reprojected_point_left.g = color[1];
    //     reprojected_point_left.b = color[0];
    //     reprojected_point_left.label = point.label;

    //     // 右相机上色
    //     x = static_cast<int>(p_2DAng1.p_2(0));
    //     y = static_cast<int>(p_2DAng1.p_2(1));
    //     color = image1.at<cv::Vec3b>(y, x);

    //     // 将投影点的颜色设置为对应像素的颜色
    //     reprojected_point_right.r = color[2];
    //     reprojected_point_right.g = color[1];
    //     reprojected_point_right.b = color[0];
    //     reprojected_point_right.label = point.label;
    // }

    // out of view
    if (ret0 != IN_IMG && ret1 != IN_IMG)
    {
        // continue;
    }

    if (ret0 == IN_IMG && ret1 != IN_IMG)// only see left camera
    {
        // 左相机上色
        // 从图像中获取对应像素的RGB值
        x = static_cast<int>(p_2DAng0.p_2(0));
        y = static_cast<int>(p_2DAng0.p_2(1));
        color = image0.at<cv::Vec3b>(y, x);

        // 将投影点的颜色设置为对应像素的颜色
        reprojected_point.r = color[2];
        reprojected_point.g = color[1];
        reprojected_point.b = color[0];
        // reprojected_points.push_back(reprojected_point);
    }
    else if (ret0 != IN_IMG && ret1 == IN_IMG)// only see right camera
    {
        // 右相机上色
        x = static_cast<int>(p_2DAng1.p_2(0));
        y = static_cast<int>(p_2DAng1.p_2(1));
        color = image1.at<cv::Vec3b>(y, x);

        // 将投影点的颜色设置为对应像素的颜色
        reprojected_point.r = color[2];
        reprojected_point.g = color[1];
        reprojected_point.b = color[0];
        // reprojected_points.push_back(reprojected_point);
    }
    else if (ret0 == IN_IMG && ret1 == IN_IMG)// see both cameras in mix area
    {
        // printf("!!!!!!!!!!!!!!!!!!!!\n");
        double w_l =0.5, w_r = 0.5;
        // double theta_l = acos(theta_l_cos);
        // double theta_r = acos(theta_r_cos);

        double theta_l = p_2DAng0.theta;
        double theta_r = p_2DAng1.theta;

        if (theta_l > ang_mix_thr && theta_r > ang_mix_thr)
        {
            w_l = (theta_r - ang_mix_thr) / ((ang_mix_thr - theta_l) + (ang_mix_thr- theta_r));
            w_r = 1.0 - w_l;
        }
        else
        {
            w_l = (theta_r - ang_mix_thr) > (theta_l - ang_mix_thr) ? 1.0 : 0.0;
            w_r = 1.0 - w_l;
        }

        // x = static_cast<int>(p_2DAng0.p_2(0));
        // y = static_cast<int>(p_2DAng0.p_2(1));
        auto color_0 = image0.at<cv::Vec3b>(static_cast<int>(p_2DAng0.p_2(1)), static_cast<int>(p_2DAng0.p_2(0)));

        // x = static_cast<int>(p_2DAng1.p_2(0));
        // y = static_cast<int>(p_2DAng1.p_2(1));
        auto color_1 = image1.at<cv::Vec3b>(static_cast<int>(p_2DAng1.p_2(1)), static_cast<int>(p_2DAng1.p_2(0)));

        // 融合reprojected_point_left和reprojected_point_right
        reprojected_point.r = w_l * color_0[2] + w_r * color_1[2];
        reprojected_point.g = w_l * color_0[1] + w_r * color_1[1];
        reprojected_point.b = w_l * color_0[0] + w_r * color_1[0];

        // reprojected_point.r = color_0[2] ;
        // reprojected_point.g = color_0[1] ;
        // reprojected_point.b = color_0[0] ;
        // reprojected_point.g = w_l * reprojected_point_left.g + w_r * reprojected_point_right.g;
        // reprojected_point.b = w_l * reprojected_point_left.b + w_r * reprojected_point_right.b;
        
        // reprojected_points.push_back(reprojected_point);           
    }

    // reprojected_points.push_back(reprojected_point);

}

// transform rgb to hsv
Eigen::Vector3f OfflineRender::rgb2hsv(const Eigen::Vector3i &rgb)
{
    float r = rgb[0] / 255.0;
    float g = rgb[1] / 255.0;
    float b = rgb[2] / 255.0;
    float max = std::max(r, std::max(g, b));
    float min = std::min(r, std::min(g, b));
    float h = 0.0, s = 0.0, v = 0.0;
    v = max;
    if (max == 0.0) s = 0.0;
    else s = (max - min) / max;

    if (max == min) h = 0.0;
    else if (max == r && g >= b) h = 60.0 * (g - b) / (max - min);
    else if (max == r && g < b) h = 60.0 * (g - b) / (max - min) + 360.0;
    else if (max == g) h = 60.0 * (b - r) / (max - min) + 120.0;
    else if (max == b) h = 60.0 * (r - g) / (max - min) + 240.0;
    // h /= 360.0;
    // printf("h: %lf, s: %lf, v: %lf\n", h, s, v);
    // transform hsv to rgb
    return Eigen::Vector3f (h, s, v);
}

Eigen::Vector3i OfflineRender::hsv2rgb(const Eigen::Vector3f &hsv)
{
    float rr = 0.0, gg = 0.0, bb = 0.0;
    float hh = hsv[0], ss = hsv[1], vv = hsv[2];
    if (ss == 0.0)
    {
        rr = vv;
        gg = vv;
        bb = vv;
    }
    else
    {
        hh /= 60.0;
        int i = (int)hh;
        float ff = hh - i;
        float p = vv * (1.0 - ss);
        float q = vv * (1.0 - ss * ff);
        float t = vv * (1.0 - ss * (1.0 - ff));
        switch (i)
        {
            case 0:
                rr = vv;
                gg = t;
                bb = p;
                break;
            case 1:
                rr = q;
                gg = vv;
                bb = p;
                break;
            case 2:
                rr = p;
                gg = vv;
                bb = t;
                break;
            case 3:
                rr = p;
                gg = q;
                bb = vv;
                break;
            case 4:
                rr = t;
                gg = p;
                bb = vv;
                break;
            case 5:
                rr = vv;
                gg = p;
                bb = q;
                break;
            default:
                break;
        }
    }
    return Eigen::Vector3i (rr * 255, gg * 255, bb * 255);
    // rgb[0] = rr * 255;
    // rgb[1] = gg * 255;
    // rgb[2] = bb * 255;
}

//根据临近像素插值 补全当前pixel
Eigen::Vector3f getpixel(cv::Mat img, Eigen::Vector2d pc, int width)
{
    const float u_ref = pc[0];
    const float v_ref = pc[1];
    if(u_ref < 0 || u_ref > width || v_ref < 0 || v_ref > img.rows) {
    cout << "Invalid coordinate: " << u_ref << ", " << v_ref << endl;
    return Eigen::Vector3f(0, 0, 0);
    }
    // 整数部分
    const int u_ref_i = floorf(pc[0]);
    const int v_ref_i = floorf(pc[1]);
    // 小数部分
    const float subpix_u_ref = (u_ref - u_ref_i);
    const float subpix_v_ref = (v_ref - v_ref_i);
    // 权重
    const float w_ref_tl = (1.0 - subpix_u_ref) * (1.0 - subpix_v_ref);
    const float w_ref_tr = subpix_u_ref * (1.0 - subpix_v_ref);
    const float w_ref_bl = (1.0 - subpix_u_ref) * subpix_v_ref;
    const float w_ref_br = subpix_u_ref * subpix_v_ref;
    uint8_t *img_ptr = (uint8_t *)img.data + ((v_ref_i)*width + (u_ref_i)) * 3;
    float B = w_ref_tl * img_ptr[0] + w_ref_tr * img_ptr[0 + 3] +
        w_ref_bl * img_ptr[width * 3] +
        w_ref_br * img_ptr[width * 3 + 0 + 3];
    float G = w_ref_tl * img_ptr[1] + w_ref_tr * img_ptr[1 + 3] +
        w_ref_bl * img_ptr[1 + width * 3] +
        w_ref_br * img_ptr[width * 3 + 1 + 3];
    float R = w_ref_tl * img_ptr[2] + w_ref_tr * img_ptr[2 + 3] +
        w_ref_bl * img_ptr[2 + width * 3] +
        w_ref_br * img_ptr[width * 3 + 2 + 3];
    Eigen::Vector3f pixel(B, G, R);
    return pixel;
}

template <typename T>
void poly2pinhole(const poly_inner<T> & inner, double scale, const Eigen::Matrix3d & rotM, const cv::Mat & img_orig, cv::Mat & img_out)
{
    
    double fx  = inner.innerT.coeffRef(0, 0);
    double A12 = inner.innerT.coeffRef(0, 1);
    double fy  = inner.innerT.coeffRef(1, 1);
    double cx  = inner.innerT.coeffRef(0, 2);
    double cy  = inner.innerT.coeffRef(1, 2);
    //k2~k7 is ocamModel.invpol[i]
    double k2  = inner.distorT[0];
    double k3  = inner.distorT[1];
    double k4  = inner.distorT[2];
    double k5  = inner.distorT[3];
    double k6  = inner.distorT[4];
    double k7  = inner.distorT[5];

    int width = img_orig.cols;
    int height = img_orig.rows;
    int width_2 = img_orig.cols * scale;
    int height_2 = img_orig.rows * scale;
    img_out = cv::Mat::zeros(height_2, width_2, img_orig.type());
    // cv::Size image_size = img_orig.size();
    // cv::Mat mapx = cv::Mat::zeros(img_orig.size(), CV_32FC1);
    // cv::Mat mapy = cv::Mat::zeros(img_orig.size(), CV_32FC1);

    // 遍历原始像素上的 每个像素
    for (int v = 0; v < height_2; v++)
    {
        for (int u = 0; u < width_2; u++)
        {
            // 原始图像的uv位置
            Eigen::Vector3d uv((u - width_2 / 2) / (fx * scale), (v - height_2 / 2) / (fy * scale), 1);

            uv = rotM * uv / uv.norm();
            
            double x = uv(0);
            double y = uv(1);

            double xd, yd;
            double r = sqrt(x * x + y * y);
            if (r < 1e-8)
            {
                // printf("r is too small\n");
                continue;
            }
            // double theta = std::atan(r);
            double theta  = acos( uv( 2 ) / uv.norm( ) );
            double theta2 = theta * theta;
            double theta3 = theta2 * theta;
            double theta4 = theta3 * theta;
            double theta5 = theta4 * theta;
            double theta6 = theta5 * theta;
            double theta7 = theta6 * theta;
            double thetad = theta + k2 * theta2 + k3 * theta3 + k4 * theta4 +
                            k5 * theta5 + k6 * theta6 + k7 * theta7;
            double scaling = thetad / r;
            xd = x * scaling;
            yd = y * scaling;
            // xd = thetad * 
            double u_distort = xd * fx + yd * A12 + cx;
            double v_distort = yd * fy + cy;

            // 在原始图像获得像素值
            if(u_distort < 0 || u_distort > width || v_distort < 0 || v_distort > height) {
                // cout << "Skip out of boundary: " << u_distort << ", " << v_distort << endl;
                // printf("Skip out of boundary: %lf, %lf\n", u_distort, v_distort);
                img_out.at<cv::Vec3b>(v, u)[0] = 0;
                img_out.at<cv::Vec3b>(v, u)[1] = 0;
                img_out.at<cv::Vec3b>(v, u)[2] = 0;
                continue;
            }
            Eigen::Vector3f pixel = getpixel(img_orig, Eigen::Vector2d(u_distort, v_distort), width);
            //输出图像
            img_out.at<cv::Vec3b>(v, u)[0] = pixel[0];
            img_out.at<cv::Vec3b>(v, u)[1] = pixel[1];
            img_out.at<cv::Vec3b>(v, u)[2] = pixel[2];
        }
    }
}

int OfflineRender::undistort_imgs(const double scale)
{
    std::string inputDir  = root_path_ + "/image";
    std::string outputDir = root_path_ + "/image_undistorted";

    if (!boost::filesystem::is_directory(outputDir))
    {
        std::cout << "begin create path: " << outputDir << std::endl;
        if (!boost::filesystem::create_directory(outputDir))
        {
            std::cout << "create_directories failed: " << outputDir << std::endl;
            return -1;
        }
    }
    else
    {
        std::cout << outputDir << " aleardy exist" << std::endl;
    }
    Eigen::Matrix3d rotM;
    // Iterate over files in the input directory
    for (const auto &entry : std::filesystem::directory_iterator(inputDir))
    {
        if (entry.is_regular_file())
        {
            std::string filename = entry.path().filename().string();
            std::string inputFile = inputDir + "/" + filename;
            

            cout << "Processing: " << inputFile << endl;

            // 如果filename的尾缀不是.jpeg，则跳过
            if (filename.substr(filename.size() - 5) != ".jpeg" && filename.substr(filename.size() - 5) != ".JPEG")
            {
                printf("Skip file: %s since it is not jpeg.\n", filename.c_str());
                continue;
            }

            // 如果filename的第四个字符不是数字，则跳过
            if (!isdigit(filename[3]))
            {
                printf("Skip file: %s since 4th character is not a number.\n", filename.c_str());
                continue;
            }

            // 根据filename的第四个字符判断相机编号，
            int camera_index = std::stoi(filename.substr(3, 1));

            // 获得filename下划线后面的数字，即图像编号
            int pic_index = std::stoi(filename.substr(filename.find("_") + 1, filename.find(".") - filename.find("_") - 1));
            
            // 载入相机内参得到fx fy cx cy k1 k2 k3 k4 k5 k6 k7 A12
            auto & inner = camParams_.inner_list[camera_index];
            cv::Mat img_orig(cv::imread(inputFile)), img_out;
            if (img_orig.empty())
            {
                cout << "Could not open or find the image: " << inputFile << endl;
                continue;
            }
            // rotate uv along Y axis and X axis
            std::string outputFile = outputDir + "/img_pinhole_" + std::to_string(pic_index)+"_"+std::to_string(camera_index*2) + ".png";
            // rotM = Eigen::AngleAxisd(-45./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(15./180.*M_PI, Eigen::Vector3d::UnitX());
            rotM = Eigen::AngleAxisd(0./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(9./180.*M_PI, Eigen::Vector3d::UnitX());
            poly2pinhole(inner, scale, rotM, img_orig, img_out);
            cv::imwrite(outputFile, img_out);

            // outputFile = outputDir + "/img_pinhole_" + std::to_string(pic_index)+"_"+std::to_string(camera_index*2+1) + ".png";
            // rotM = Eigen::AngleAxisd(45./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(15./180.*M_PI, Eigen::Vector3d::UnitX());
            // poly2pinhole(inner, scale, rotM, img_orig, img_out);
            // cv::imwrite(outputFile, img_out);

            std::cout << "Processed image saved: " << outputFile << std::endl;
        }
    }
    return 1;
}

void OfflineRender::run(std::string lx_file_name, bool need_undistort)
{
    printf("start offline render develop.\n");
    auto start_t = clock();
    std::vector<pcl::PointXYZRGBL> pclPointsVec;
    std::vector<PointXYZRGBI>      pointsVec;
    uint32_t                       numberOfIntensity;
    // CamParams<double> camParams_;
    std::vector<Eigen::Matrix4d> cam_pose;

    float voxelSize = 0.05f;
    float voxelSizeHalf = voxelSize / 2.0f;
    // get dir name using std's std::string

    lx_file_name_ = lx_file_name; // "/home/xw/XW/Bags/Panora/2023-08-22-10-41-46/MANIFOLD_2023-08-22-10-41-46.lx";
    // std::string lx_file_name_ = "/home/xw/XW/Bags/Panora/Panora_0414_stjohn_raw/RawData/2023-04-15-04-48-2floor3room/MANIFOLD_2023-04-15-04-48-3ro.lx";
    // std::string lx_file_name_ = "/home/xw/XW/Bags/Panora/2023-06-16-11-42-07/MANIFOLD_2023-06-16-11-42-07.lx";

    need_undistort_ = need_undistort;
    // std::string lx_file_name_ = "/home/xw/Log/2023-06-19/aaa.lx";

    // std::string root_path_ = filename.toStdString();
    // printf("lx_file_name_: %s\n", lx_file_name_.c_str());
    root_path_ = lx_file_name_.substr(0, lx_file_name_.find_last_of("/\\"));
    std::string camfile = root_path_ + "/image/cam_in_ex.txt";
    std::string imgframe_imu_pose_file = root_path_ + "/image/img_pos.txt";

    auto readStart = clock();
    LxTools lxreader;
    bool bf = lxreader.readSumFile(lx_file_name_, pclPointsVec, pointsVec, cam_pose, numberOfIntensity);
    // while (cam_pose.size() > 330)
    {
        cam_pose.pop_back();
        cam_pose.pop_back();
    }

    if (!bf) {
        std::cout << "readSumFile failed" << std::endl;
        return;
    }
    printf ("LX points contains: %d, used time: %0.4lf s\n", pointsVec.size(), (double)(clock() - readStart) / (CLOCKS_PER_SEC));

    parse_cam_params(camfile, camParams_.inner_list, camParams_.ext_list);
    

    // 载入Section参数
    // std::map<int, std::tuple<float, float, float, float, float, float, float, float>> cam_pose;
    
    // loadSectionParams(imgframe_imu_pose_file, cam_pose);
    printf("cam_pose.size() = %d \n", cam_pose.size());
    // save cam_pose to point cloud
    pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cam_pose_cloud(new pcl::PointCloud<pcl::PointXYZRGBL>);
    cam_pose_cloud->points.reserve(cam_pose.size());
    
    for (auto it = cam_pose.begin(); it != cam_pose.end(); ++it)
    {
        pcl::PointXYZRGBL point;
        point.x = (*it)(0, 3);
        point.y = (*it)(1, 3);
        point.z = (*it)(2, 3);
        point.r = 255;
        point.g = 0;
        point.b = 0;
        point.label = 0;
        cam_pose_cloud->points.push_back(point);
    }

    if (need_undistort_)
    {
        if (undistort_imgs(0.5) < 0) {
            std::cout << "undistort_imgs failed" << std::endl;
            return;
        }
    }

    // return;
    // pcl::io::savePLYFileBinary(root_path_ + "/cam_pose_cloud.ply", *cam_pose_cloud);

    // 载入Section图像
    // std::vector<cv::Mat> left_images;
    // std::vector<cv::Mat> right_images;
    std::map<int, cv::Mat> left_images;
    std::map<int, cv::Mat> right_images;
    std::string image_path = root_path_ + "/image";
    loadSectionImage(image_path, left_images, right_images);
    // 显示图像数量
    
    printf("left_images.size() = %d \n", left_images.size());
    printf("right_images.size() = %d \n", right_images.size());
    
    std::string texture_img_dir = root_path_ + "/image_undistorted_text";
    if (!boost::filesystem::is_directory(texture_img_dir))
    {
        std::cout << "begin create path: " << texture_img_dir << std::endl;
        if (!boost::filesystem::create_directory(texture_img_dir))
        {
            std::cout << "create_directories failed: " << texture_img_dir << std::endl;
            return;
        }
    }
    else
    {
        std::cout << texture_img_dir << " aleardy exist" << std::endl;
    }
    
    TiXmlDocument *writeXML = new TiXmlDocument; //xml文档指针
    //xml文档格式声明
    TiXmlDeclaration *decl = new TiXmlDeclaration("1.0", "UTF-8", "yes");
    writeXML->LinkEndChild(decl); //写入文档
    TiXmlElement *RootElement = new TiXmlElement("document");//根元素
    RootElement->SetAttribute("version", "1.2.0"); //属性
    writeXML->LinkEndChild(RootElement);
    TiXmlElement *chunkElement = new TiXmlElement("chunk");//根元素
    RootElement->LinkEndChild(chunkElement);
    TiXmlElement *SensorsElement = new TiXmlElement("sensors");//根元素
    chunkElement->LinkEndChild(SensorsElement);
    const auto & inner_l = camParams_.inner_list[0];
    const auto & inner_r = camParams_.inner_list[1];
    unsigned int cam_width = inner_l.width;
    unsigned int cam_height = inner_l.height;
    std::string fx[2] = {std::to_string(inner_l.innerT(0,0)), std::to_string(inner_r.innerT(0,0))};
    std::string fy[2] = {std::to_string(inner_l.innerT(1,1)), std::to_string(inner_r.innerT(1,1))};
    for (int i = 0; i < 2; i ++)
    {
        TiXmlElement *SensorElement = new TiXmlElement("sensor");//根元素
        SensorElement->SetAttribute("id", i); //属性
        SensorElement->SetAttribute("label", "unknown0"); //属性
        SensorElement->SetAttribute("type", "frame"); //属性
        SensorsElement->LinkEndChild(SensorElement);
        TiXmlElement *ResolutionElement = new TiXmlElement("resolution");//根元素
        ResolutionElement->SetAttribute("width", cam_width); //属性
        ResolutionElement->SetAttribute("height", cam_height); //属性
        SensorElement->LinkEndChild(ResolutionElement);
        TiXmlElement *CalibrationElement = new TiXmlElement("calibration");//根元素
        CalibrationElement->SetAttribute("type", "frame"); //属性
        CalibrationElement->SetAttribute("class", "adjusted"); //属性
        SensorElement->LinkEndChild(CalibrationElement);
        TiXmlElement *Resolution2Element = new TiXmlElement("resolution");//根元素
        Resolution2Element->SetAttribute("width", cam_width); //属性
        Resolution2Element->SetAttribute("height", cam_height); //属性
        TiXmlElement *fxElement = new TiXmlElement("fx");//根元素
        TiXmlText *fxContent = new TiXmlText(fx[i]);
        fxElement->LinkEndChild(fxContent);
        TiXmlElement *fyElement = new TiXmlElement("fy");//根元素
        TiXmlText *fyContent = new TiXmlText(fy[i]);
        fyElement->LinkEndChild(fyContent);
        TiXmlElement *cxElement = new TiXmlElement("cx");//根元素
        TiXmlText *cxContent = new TiXmlText(std::to_string(cam_width/2));
        cxElement->LinkEndChild(cxContent);
        TiXmlElement *cyElement = new TiXmlElement("cy");//根元素
        TiXmlText *cyContent = new TiXmlText(std::to_string(cam_height/2));
        cyElement->LinkEndChild(cyContent);
        // TiXmlElement *k1Element = new TiXmlElement("k1");//根元素
        // TiXmlText *k1Content = new TiXmlText("0");
        // k1Element->LinkEndChild(k1Content);
        // TiXmlElement *k2Element = new TiXmlElement("k2");//根元素
        // TiXmlText *k2Content = new TiXmlText("0");
        // k2Element->LinkEndChild(k2Content);
        // TiXmlElement *p1Element = new TiXmlElement("p1");//根元素
        // TiXmlText *p1Content = new TiXmlText("0");
        // p1Element->LinkEndChild(p1Content);
        // TiXmlElement *p2Element = new TiXmlElement("p2");//根元素
        // TiXmlText *p2Content = new TiXmlText("0");
        // p2Element->LinkEndChild(p2Content);
        CalibrationElement->LinkEndChild(Resolution2Element);
        CalibrationElement->LinkEndChild(fxElement);
        CalibrationElement->LinkEndChild(fyElement);
        CalibrationElement->LinkEndChild(cxElement);
        CalibrationElement->LinkEndChild(cyElement);
        // CalibrationElement->LinkEndChild(k1Element);
        // CalibrationElement->LinkEndChild(k2Element);
        // CalibrationElement->LinkEndChild(p1Element);
        // CalibrationElement->LinkEndChild(p2Element);
    }
    TiXmlElement *CamerasElement = new TiXmlElement("cameras");//根元素
    chunkElement->LinkEndChild(CamerasElement);
    std::string img0_pos_filename = root_path_ + "/image0_poses.csv";
    std::string img1_pos_filename = root_path_ + "/image1_poses.csv";
    std::ofstream fout_img0_pos(img0_pos_filename, std::ios::out);
    std::ofstream fout_img1_pos(img1_pos_filename, std::ios::out);
    int start = 6, end = 187;
    int raster_i = 0;
    for (int i = start; i < end; i = i + 1)
    {
        Eigen::Matrix4d pose = cam_pose[i];
        // fout << std::to_string(i) + ".pcd " <<pose(0,0)<<" "<<pose(0,1)<<" "<<pose(0,2)<<" "<<pose(0,3)<<" "
        //     <<pose(1,0)<<" "<<pose(1,1)<<" "<<pose(1,2)<<" "<<pose(1,3)<<" "
        //     <<pose(2,0)<<" "<<pose(2,1)<<" "<<pose(2,2)<<" "<<pose(2,3)<<" "
        //     <<pose(3,0)<<" "<<pose(3,1)<<" "<<pose(3,2)<<" "<<pose(3,3)<<"\n";
        
        static Eigen::Matrix4d T_i_l = Eigen::Matrix4d::Identity(); 
        T_i_l << 1, 0, 0, -0.011,
                0, 1, 0, -0.02329,
                0, 0, 1, 0.04412,
                0, 0, 0, 1;
        // Eigen::Matrix4d T_reverse = (pose * T_i_l).inverse();
        Eigen::Matrix<double, 4, 4> T_left  = (pose * T_i_l) * camParams_.ext_list[0].Tcl.inverse().eval();
        Eigen::Matrix<double, 4, 4> T_right = (pose * T_i_l) * camParams_.ext_list[1].Tcl.inverse().eval();

        Eigen::Quaterniond q0(T_left.block<3,3>(0,0));
        fout_img0_pos << std::to_string(i)<<","<<q0.w()<<","<<q0.x()<<","<<q0.y()<<","<<q0.z()<<","<<T_left(0,3)<<","<<T_left(1,3)<<","<<T_left(2,3)<< std::endl;
        Eigen::Quaterniond q1(T_right.block<3,3>(0,0));
        fout_img1_pos << std::to_string(i)<<","<<q1.w()<<","<<q1.x()<<","<<q1.y()<<","<<q1.z()<<","<<T_right(0,3)<<","<<T_right(1,3)<<","<<T_right(2,3)<<"\n";

        std::string img_name_left  = "img_"+std::to_string(i)+"_0.png";
        std::string img_name_right = "img_"+std::to_string(i)+"_1.png";

        // left
        TiXmlElement *CameraElement_left = new TiXmlElement("camera");//Stu
        CameraElement_left->SetAttribute("id", raster_i);
        CameraElement_left->SetAttribute("label", img_name_left);
        CameraElement_left->SetAttribute("sensor_id", 0);
        CameraElement_left->SetAttribute("enabled", "true");
        CamerasElement->LinkEndChild(CameraElement_left);//父节点写入文档
        TiXmlElement *transformElement_left = new TiXmlElement("transform");
        CameraElement_left->LinkEndChild(transformElement_left);
        std::string T_left_str = std::to_string(T_left(0,0))+" "+std::to_string(T_left(0,1))+" "+std::to_string(T_left(0,2))+" "+std::to_string(T_left(0,3))+" "+
                            std::to_string(T_left(1,0))+" "+std::to_string(T_left(1,1))+" "+std::to_string(T_left(1,2))+" "+std::to_string(T_left(1,3))+" "+
                            std::to_string(T_left(2,0))+" "+std::to_string(T_left(2,1))+" "+std::to_string(T_left(2,2))+" "+std::to_string(T_left(2,3))+" "+
                            std::to_string(T_left(3,0))+" "+std::to_string(T_left(3,1))+" "+std::to_string(T_left(3,2))+" "+std::to_string(T_left(3,3));
        TiXmlText *transformContent_left = new TiXmlText(T_left_str.c_str());
        transformElement_left->LinkEndChild(transformContent_left);
        raster_i++;


        // right
        
        TiXmlElement *CameraElement_right = new TiXmlElement("camera");//Stu
        CameraElement_right->SetAttribute("id", raster_i);
        CameraElement_right->SetAttribute("label", img_name_right.c_str());
        CameraElement_right->SetAttribute("sensor_id", 1);
        CameraElement_right->SetAttribute("enabled", "true");
        CamerasElement->LinkEndChild(CameraElement_right);//父节点写入文档
        TiXmlElement *transformElement_right = new TiXmlElement("transform");
        CameraElement_right->LinkEndChild(transformElement_right);
        std::string T_right_str = std::to_string(T_right(0,0))+" "+std::to_string(T_right(0,1))+" "+std::to_string(T_right(0,2))+" "+std::to_string(T_right(0,3))+" "+
                            std::to_string(T_right(1,0))+" "+std::to_string(T_right(1,1))+" "+std::to_string(T_right(1,2))+" "+std::to_string(T_right(1,3))+" "+
                            std::to_string(T_right(2,0))+" "+std::to_string(T_right(2,1))+" "+std::to_string(T_right(2,2))+" "+std::to_string(T_right(2,3))+" "+
                            std::to_string(T_right(3,0))+" "+std::to_string(T_right(3,1))+" "+std::to_string(T_right(3,2))+" "+std::to_string(T_right(3,3));
        TiXmlText *transformContent_right = new TiXmlText(T_right_str);
        transformElement_right->LinkEndChild(transformContent_right);
        raster_i++;

        // std::string img_name_left_in = root_path_ + "/image_undistorted/img0_"+std::to_string(i)+".png";
        // std::string img_name_right_in = root_path_ + "/image_undistorted/img1_"+std::to_string(i)+".png";
        // std::string img_name_left_out = texture_img_dir + "/img_"+std::to_string(i)+"_0.png";
        // std::string img_name_right_out = texture_img_dir + "/img_"+std::to_string(i)+"_1.png";
        // cv::Mat img_left = cv::imread(img_name_left_in);
        // cv::Mat img_right = cv::imread(img_name_right_in);
        // cv::imwrite(img_name_left_out, img_left);
        // cv::imwrite(img_name_right_out, img_right);
    }

    std::string cam_info_dir = root_path_ + "/cam_info.xml";
    if (! writeXML->SaveFile(cam_info_dir))
        std::cout << "save xml file " << cam_info_dir << " failed!" << std::endl;

    std::string pcd_dir = root_path_ + "/point_cloud/";
    if (!boost::filesystem::is_directory(pcd_dir))
    {
        std::cout << "begin create path: " << pcd_dir << std::endl;
        if (!boost::filesystem::create_directory(pcd_dir))
        {
            std::cout << "create_directories failed: " << pcd_dir << std::endl;
            return;
        }
    }
    else
    {
        std::cout << pcd_dir << " aleardy exist" << std::endl;
    }
    std::string pos_filename = root_path_ + "/point_cloud/lidar_poses.csv";
    std::ofstream fout(pos_filename, std::ios::out);
    for (int i = start; i < end; ++i)
    {
        if (i > (cam_pose.size()-2)) break;
        auto & frame = lxreader.cloud_frame_list_[i];
        std::string pcd_filename = pcd_dir + "scan_" + std::to_string(i) + ".pcd";
        // save frame to pcd_filename
        // pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZRGBL>);
        // cloud->points.reserve(frame.size());
        // for (auto & point : frame)
        // {
        //     pcl::PointXYZRGBL p;
        //     p.x = point.x;
        //     p.y = point.y;
        //     p.z = point.z;
        //     p.r = point.r;
        //     p.g = point.g;
        //     p.b = point.b;
        //     p.label = point.label;
        //     cloud->points.push_back(p);
        // }
        // cloud->width = cloud->points.size();
        // cloud->height = 1;
        // cloud->is_dense = false;

        

        pcl::io::savePCDFileBinary(pcd_filename, *frame);

        // save cam_pose to pos_filename
        Eigen::Matrix4d pose = cam_pose[i];
        // transform *frame to body frame using cam_pose[i]
        // for (auto pt : frame->points)
        // {
        //     Eigen::Vector4d pt_w();
        // }

        
        // fout << std::to_string(i) + ".pcd " <<pose(0,0)<<" "<<pose(0,1)<<" "<<pose(0,2)<<" "<<pose(0,3)<<" "
        //     <<pose(1,0)<<" "<<pose(1,1)<<" "<<pose(1,2)<<" "<<pose(1,3)<<" "
        //     <<pose(2,0)<<" "<<pose(2,1)<<" "<<pose(2,2)<<" "<<pose(2,3)<<" "
        //     <<pose(3,0)<<" "<<pose(3,1)<<" "<<pose(3,2)<<" "<<pose(3,3)<<"\n";
        Eigen::Quaterniond q(pose.block<3,3>(0,0));
        fout << std::to_string(i)<<","<<q.w()<<","<<q.x()<<","<<q.y()<<","<<q.z()<<","<<pose(0,3)<<","<<pose(1,3)<<","<<pose(2,3)<<std::endl;
        
        
        // Eigen::Matrix4d T_reverse = (pose * T_i_l).inverse();
        Eigen::Matrix<double, 4, 4> T_left = (cam_pose[i] * T_i_l_) * camParams_.ext_list[0].Tcl.inverse().eval();
        Eigen::Matrix<double, 4, 4> T_right = (cam_pose[i] * T_i_l_) * camParams_.ext_list[1].Tcl.inverse().eval();
        // T_left = T_left.inverse().eval();
        // T_right = T_right.inverse().eval();
        std::string img_name_left = "img0_"+std::to_string(i)+".png";
        std::string img_name_right = "img1_"+std::to_string(i)+".png";
        
        // fout<<img_name_left
        //     <<T_left(0,0)<<" "<<T_left(0,1)<<" "<<T_left(0,2)<<" "<<T_left(0,3)<<" "
        //     <<T_left(1,0)<<" "<<T_left(1,1)<<" "<<T_left(1,2)<<" "<<T_left(1,3)<<" "
        //     <<T_left(2,0)<<" "<<T_left(2,1)<<" "<<T_left(2,2)<<" "<<T_left(2,3)<<" "
        //     <<T_left(3,0)<<" "<<T_left(3,1)<<" "<<T_left(3,2)<<" "<<T_left(3,3)<<"\n";
        // fout<<img_name_right
        //     <<T_right(0,0)<<" "<<T_right(0,1)<<" "<<T_right(0,2)<<" "<<T_right(0,3)<<" "
        //     <<T_right(1,0)<<" "<<T_right(1,1)<<" "<<T_right(1,2)<<" "<<T_right(1,3)<<" "
        //     <<T_right(2,0)<<" "<<T_right(2,1)<<" "<<T_right(2,2)<<" "<<T_right(2,3)<<" "
        //     <<T_right(3,0)<<" "<<T_right(3,1)<<" "<<T_right(3,2)<<" "<<T_right(3,3)<<"\n";
    }

    // 显示,save点云
    pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZRGBL>);
    cloud->points.reserve(pointsVec.size());
    for (int i = 0; i < pclPointsVec.size(); ++i)
    {
        // if (abs(pclPointsVec[i].x) > 13.0 && abs(pclPointsVec[i].x) < 22.0 && (pclPointsVec[i].y) > 5.0 && abs(pclPointsVec[i].z) < 2.0)
        if (pclPointsVec[i].label < cam_pose.size())
            cloud->points.push_back(pclPointsVec[i]);
    }

    

    // COLMAP output
    std::string colmap_dir = root_path_ + "/colmap";
    if (!boost::filesystem::is_directory(colmap_dir))
    {
        std::cout << "begin create COLMAP output path: " << colmap_dir << std::endl;
        if (!boost::filesystem::create_directory(colmap_dir))
        {
            std::cout << "create COLMAP output path failed: " << colmap_dir << std::endl;
            return;
        }
    }
    else
    {
        std::cout << colmap_dir << " aleardy exist" << std::endl;
    }
    std::string colmap_img_dir = colmap_dir + "/images";
    if (!boost::filesystem::is_directory(colmap_img_dir))
    {
        std::cout << "begin create COLMAP images output path: " << colmap_img_dir << std::endl;
        if (!boost::filesystem::create_directory(colmap_img_dir))
        {
            std::cout << "create COLMAP images output path failed: " << colmap_img_dir << std::endl;
            return;
        }
    }
    else
    {
        std::cout << colmap_img_dir << " aleardy exist" << std::endl;
    }
    std::string colmap_sparse_dir = colmap_dir + "/sparse";
    if (!boost::filesystem::is_directory(colmap_sparse_dir))
    {
        std::cout << "begin create COLMAP sparse output path: " << colmap_sparse_dir << std::endl;
        if (!boost::filesystem::create_directory(colmap_sparse_dir))
        {
            std::cout << "create COLMAP sparse output path failed: " << colmap_sparse_dir << std::endl;
            return;
        }
    }
    else
    {
        std::cout << colmap_sparse_dir << " aleardy exist" << std::endl;
    }
    std::string cameras_filename = colmap_sparse_dir + "/cameras.txt";
    std::string points3D_filename = colmap_sparse_dir + "/points3D.txt";
    std::string images_filename = colmap_sparse_dir + "/images.txt";
    std::ofstream fout_cameras(cameras_filename, std::ios::out);
    std::ofstream fout_images(images_filename, std::ios::out);
    std::ofstream fout_points3D(points3D_filename, std::ios::out);
    double scale = 0.5;
    double max_ang = 200.0/180.0*M_PI;
    double pinhole_fx_l = inner_l.innerT(0,0)*scale;
    double pinhole_fy_l = inner_l.innerT(1,1)*scale;
    double pinhole_fx_r = inner_r.innerT(0,0)*scale;
    double pinhole_fy_r = inner_r.innerT(1,1)*scale;
    double pinhole_cx = inner_l.width*scale*0.5;
    double pinhole_cy = inner_l.height*scale*0.5;
    double pinhole_width = inner_l.width*scale;
    double pinhole_height = inner_l.height*scale;
    fout_cameras<< 1 <<" PINHOLE "<<inner_l.width*scale<<" "<<inner_l.height*scale<<" "<<inner_l.innerT(0,0)*scale<<" "<<inner_l.innerT(1,1)*scale<<" "<<inner_l.width*scale*0.5<<" "<<inner_l.height*scale*0.5<<std::endl
                << 2 <<" PINHOLE "<<inner_l.width*scale<<" "<<inner_l.height*scale<<" "<<inner_l.innerT(0,0)*scale<<" "<<inner_l.innerT(1,1)*scale<<" "<<inner_l.width*scale*0.5<<" "<<inner_l.height*scale*0.5<<std::endl
                << 3 <<" PINHOLE "<<inner_r.width*scale<<" "<<inner_r.height*scale<<" "<<inner_r.innerT(0,0)*scale<<" "<<inner_r.innerT(1,1)*scale<<" "<<inner_r.width*scale*0.5<<" "<<inner_r.height*scale*0.5<<std::endl
                << 4 <<" PINHOLE "<<inner_r.width*scale<<" "<<inner_r.height*scale<<" "<<inner_r.innerT(0,0)*scale<<" "<<inner_r.innerT(1,1)*scale<<" "<<inner_r.width*scale*0.5<<" "<<inner_r.height*scale*0.5<<std::endl;

    Eigen::Matrix3d rotM;
    Eigen::Matrix4d T_fish_pinhole_0, T_fish_pinhole_1;
    T_fish_pinhole_0.setIdentity(); T_fish_pinhole_1.setIdentity();
    // rotM = Eigen::AngleAxisd(-45./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(15./180.*M_PI, Eigen::Vector3d::UnitX());
    rotM = Eigen::AngleAxisd(0./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(12./180.*M_PI, Eigen::Vector3d::UnitX());
    T_fish_pinhole_0.block<3,3>(0,0) = rotM;
    // rotM = Eigen::AngleAxisd(45./180.*M_PI, Eigen::Vector3d::UnitY()) * Eigen::AngleAxisd(15./180.*M_PI, Eigen::Vector3d::UnitX());
    T_fish_pinhole_1.block<3,3>(0,0) = rotM;
    std::vector<std::vector<Eigen::Matrix4d>> pinhole_pose_list(4);
    std::vector<std::vector<Eigen::Matrix4d>> fish_pose_list(4);
    std::vector<COLMAP_IN::FRAME> frame_list;
    std::unordered_map<int, int> keyframe_map; // map frame to key frame
    for (int i = 0; i < cam_pose.size(); i ++)
    {
        if (i > 0)  
        {
            double dist = (cam_pose[i].block<3,1>(0,3) - cam_pose[i-1].block<3,1>(0,3)).norm();
            // 计算两个旋转矩阵之间的角度
            Eigen::Matrix3d rotM0 = cam_pose[i].block<3,3>(0,0);
            Eigen::Matrix3d rotM1 = cam_pose[i-1].block<3,3>(0,0);
            Eigen::Matrix3d rotM = rotM0 * rotM1.transpose();
            Eigen::AngleAxisd angleAxis(rotM);
            double angle = angleAxis.angle();

            if (dist < 0.1 && angle < 0.09)  
            {
                if (keyframe_map.find(i-1) == keyframe_map.end())
                {
                    keyframe_map[i] = i - 1;
                }
                else
                {
                    keyframe_map[i] = keyframe_map[i-1];
                }

                printf("Merged frame %d to keyframe %d\n", i, keyframe_map[i]);
            }
            else
            {
                keyframe_map[i] = i;
                printf("New keyframe %d\n", i);
            }
        }
        auto & campos = cam_pose[i];

        Eigen::Matrix<double, 4, 4> T_left  = (campos * T_i_l_) * camParams_.ext_list[0].Tcl.inverse().eval();
        Eigen::Matrix<double, 4, 4> T_right = (campos * T_i_l_) * camParams_.ext_list[1].Tcl.inverse().eval();

        
        fish_pose_list[0].push_back(T_left.inverse().eval());
        fish_pose_list[1].push_back(T_right.inverse().eval());

        pinhole_pose_list[0].push_back((T_left * T_fish_pinhole_0).inverse().eval());
        pinhole_pose_list[1].push_back((T_left * T_fish_pinhole_1).inverse().eval());
        pinhole_pose_list[2].push_back((T_right * T_fish_pinhole_0).inverse().eval());
        pinhole_pose_list[3].push_back((T_right * T_fish_pinhole_1).inverse().eval());

        for (int id = 0; id < 4; id ++)
        {
            COLMAP_IN::FRAME cam(COLMAP_IN::PINHOLE, id, pinhole_pose_list[id].back()); // cam_id start with 1 not 0, so using i+1 nor i
            frame_list.push_back(cam);
        }
    }
    // downsample the cloud
    start_t = clock();printf("start downsample the cloud...\n");
    pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cloud_filtered(new pcl::PointCloud<pcl::PointXYZRGBL>);
    double ds_size = 0.005;
    VoxelDownsampleFilter ds_filter(ds_size);
    ds_filter.filt(cloud, cloud_filtered);
    unsigned int cloud_num = cloud->points.size();
    unsigned int ds_num = cloud_filtered->points.size();
    printf("downsample the cloud size from %d to %d used time: %0.4lf s\n", cloud_num, ds_num, (double)(clock() - start) / (CLOCKS_PER_SEC));

    // 建立kdtree
    start_t = clock();printf("start building kdtree...\n");
    pcl::KdTreeFLANN<pcl::PointXYZRGBL> kdtree;
    kdtree.setInputCloud(cloud_filtered);
    printf("build kdtree used time: %0.4lf s\n", (double)(clock() - start_t) / (CLOCKS_PER_SEC));
    printf("start writing point.txt...\n");
    printf("total pt num: %d\n", ds_num);
    double radius = ds_size * 4.0;
    std::vector<bool> effect_pt_flg(ds_num, true);
    bool print_flg = false;
    for (int i = 0; i < cloud_filtered->points.size(); ++i)
    {
        print_flg = (i % 100000 == 0); 
        if (print_flg)  printf("processing %d-th point, %f \%\n", i, float(i)/ds_num*100);
        // std::cin.get();

        auto & proc_pt = cloud_filtered->points[i];
        if (!effect_pt_flg[i]) continue;
        
        std::vector<int> pointIdxRadiusSearch;
        std::vector<float> pointRadiusSquaredDistance;
        if (kdtree.radiusSearch(proc_pt, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) < 0)
        {
            // printf("no neighbours!\n");
            continue;
        }
        Eigen::Vector3d p_w(proc_pt.x, proc_pt.y, proc_pt.z);
        std::unordered_map<unsigned int, bool> fish_index_map;
        std::vector<COLMAP_IN::FRAME> frame_list_local;
        pointIdxRadiusSearch.push_back(i);
        pointRadiusSquaredDistance.push_back(100000);
        for (int j = 0; j < pointIdxRadiusSearch.size(); j ++)
        {
            auto & pt_neighb = cloud_filtered->points[pointIdxRadiusSearch[j]];
            unsigned int fisheye_index = keyframe_map[pt_neighb.label];
            // unsigned int fisheye_index = pt_neighb.label;
            // printf("%d-th neighbour: pt %d, label %d\n", j, pointIdxRadiusSearch[j], fisheye_index);
            
            if (pointRadiusSquaredDistance[j] < ds_size*ds_size*2)  effect_pt_flg[i] = false;
            if (fish_index_map[fisheye_index] == true) continue;
            
            Eigen::Matrix4d cam_fish_l = fish_pose_list[0][fisheye_index];
            Eigen::Matrix4d cam_fish_r = fish_pose_list[1][fisheye_index];

            

            
            // Eigen::Vector3d pt_fish_l = cam_fish_l.block(0, 0, 3, 3) * pt_w + cam_fish_l.block(0, 3, 3, 1);
            PolyProject poly_project; Proj2DAng<double> p_2DAng;
            Eigen::Vector3d pt_pinhole(0.0, 0.0, 0.0);
            if (IN_IMG == poly_project.point_project(p_w, cam_fish_l, inner_l, max_ang, p_2DAng, 20))
            {
                auto & u = p_2DAng.p_2(0);
                auto & v = p_2DAng.p_2(1);
                
                // if (u > 0 && u < inner_l.innerT(0,2))
                {
                    unsigned int pinhole_index = 4 * fisheye_index + 0;
                    auto & T_pinhole = pinhole_pose_list[0][fisheye_index];
                    pt_pinhole = T_pinhole.block<3,3>(0,0) * p_w + T_pinhole.block<3,1>(0,3);
                    double x = pt_pinhole(0) * pinhole_fx_l / pt_pinhole(2) + pinhole_cx;
                    double y = pt_pinhole(1) * pinhole_fy_l / pt_pinhole(2) + pinhole_cy;
                    if (x > 0 && x < pinhole_width && y > 0 && y < pinhole_height && pt_pinhole(2) > 0.001)
                    {
                        frame_list_local.push_back(COLMAP_IN::FRAME(COLMAP_IN::PINHOLE, pinhole_index, T_pinhole));
                        frame_list_local.back().keypoint_list.push_back(COLMAP_IN::KEYPOINT2D(x, y, i));
                    }
                    // else  printf("0 failed, x %lf y %lf\n", x, y);
                }
                // else if (u > inner_l.innerT(0,2) && u < inner_l.width)
                // {
                //     unsigned int pinhole_index = 4 * fisheye_index + 1;
                //     auto & T_pinhole = pinhole_pose_list[1][fisheye_index];
                //     pt_pinhole = T_pinhole.block<3,3>(0,0) * p_w + T_pinhole.block<3,1>(0,3);
                //     double x = pt_pinhole(0) * pinhole_fx_l / pt_pinhole(2) + pinhole_cx;
                //     double y = pt_pinhole(1) * pinhole_fy_l / pt_pinhole(2) + pinhole_cy;
                //     if (x > 0 && x < pinhole_width && y > 0 && y < pinhole_height && pt_pinhole(2) > 0.001)
                //     {
                //         frame_list_local.push_back(COLMAP_IN::FRAME(COLMAP_IN::PINHOLE, pinhole_index, T_pinhole));
                //         frame_list_local.back().keypoint_list.push_back(COLMAP_IN::KEYPOINT2D(x, y, i));
                //     }
                //     // else  printf("1 failed, x %lf y %lf\n", x, y);
                // }
            }
            
            if (IN_IMG == poly_project.point_project(p_w, cam_fish_r, inner_r, max_ang, p_2DAng, 20))
            {
                auto & u = p_2DAng.p_2(0);
                auto & v = p_2DAng.p_2(1);
                // if (u > 0 && u < inner_r.innerT(0,2))
                {
                    unsigned int pinhole_index = 4 * fisheye_index + 2;
                    auto & T_pinhole = pinhole_pose_list[2][fisheye_index];
                    pt_pinhole = T_pinhole.block<3,3>(0,0) * p_w + T_pinhole.block<3,1>(0,3);
                    double x = pt_pinhole(0) * pinhole_fx_r / pt_pinhole(2) + pinhole_cx;
                    double y = pt_pinhole(1) * pinhole_fy_r / pt_pinhole(2) + pinhole_cy;
                    if (x > 0 && x < pinhole_width && y > 0 && y < pinhole_height && pt_pinhole(2) > 0.001)
                    {
                        frame_list_local.push_back(COLMAP_IN::FRAME(COLMAP_IN::PINHOLE, pinhole_index, T_pinhole));
                        frame_list_local.back().keypoint_list.push_back(COLMAP_IN::KEYPOINT2D(x, y, i));
                    }
                    // else  printf("x %lf y %lf\n", x, y);
                }
                // else if (u > inner_r.innerT(0,2) && u < inner_r.width)
                // {
                //     unsigned int pinhole_index = 4 * fisheye_index + 3;
                //     auto & T_pinhole = pinhole_pose_list[3][fisheye_index];
                //     pt_pinhole = T_pinhole.block<3,3>(0,0) * p_w + T_pinhole.block<3,1>(0,3);
                //     double x = pt_pinhole(0) * pinhole_fx_r / pt_pinhole(2) + pinhole_cx;
                //     double y = pt_pinhole(1) * pinhole_fy_r / pt_pinhole(2) + pinhole_cy;
                //     if (x > 0 && x < pinhole_width && y > 0 && y < pinhole_height && pt_pinhole(2) > 0.001)
                //     {
                //         frame_list_local.push_back(COLMAP_IN::FRAME(COLMAP_IN::PINHOLE, pinhole_index, T_pinhole));
                //         frame_list_local.back().keypoint_list.push_back(COLMAP_IN::KEYPOINT2D(x, y, i));
                //     }
                //     // else  printf("x %lf y %lf\n", x, y);
                // }
            }

            fish_index_map[fisheye_index] = true;
            // if (print_flg)  printf("searced label: %d finded %d frames, pt_pinhole: %lf %lf %lf !\n", \
            //                         fisheye_index, frame_list_local.size(), pt_pinhole(0), pt_pinhole(1), pt_pinhole(2));
        }

        if (print_flg)   printf("frame_list_local size: %d\n", frame_list_local.size());

        if (frame_list_local.size() <= 2) 
        {
            // printf("not enough view, neighbour size: %d view size %d \n", pointIdxRadiusSearch.size(), pinhole_index_list.size());
            continue;
        }

        fout_points3D<<i<<" "<<proc_pt.x<<" "<<proc_pt.y<<" "<<proc_pt.z<<" "<<(int)proc_pt.r<<" "<<(int)proc_pt.g<<" "<<(int)proc_pt.b<<" 0.1";
        for (auto & frame : frame_list_local)
        {
            unsigned int index = frame.cam_id;
            frame_list[index].keypoint_list.push_back(frame.keypoint_list[0]);
            fout_points3D<<" "<<index+1<<" "<<frame_list[index].keypoint_list.size()-1;
        }
        fout_points3D<<std::endl;
    }
    fout_points3D.close();
    printf("finished writing point.txt\n");
    printf("start writing images.txt...\n");
    // 清空colmap_img_dir内所有images
    


    for (int i = 0; i < frame_list.size(); i ++)
    {
        auto & frame = frame_list[i];
        if (frame.keypoint_list.empty())  continue;
        Eigen::Quaterniond q(frame.T.block<3,3>(0,0));
        std::string img_name = "img_pinhole_" + std::to_string(i/4) + "_" + std::to_string(frame.cam_id) + ".png";
        fout_images<<i+1<<" "<<q.w()<<" "<<q.x()<<" "<<q.y()<<" "<<q.z()<<" "<<frame.T(0,3)<<" "<<frame.T(1,3)<<" "<<frame.T(2,3)<<" "<<frame.cam_id+1<<" "<<img_name<<std::endl;
        for (auto & keypoint : frame.keypoint_list)
        {
            fout_images<<" "<<keypoint.u<<" "<<keypoint.v<<" "<<keypoint.point3D_id;
        }
        fout_images<<std::endl;
    }
    printf("finished writing images.txt, takes \n");

    start_t = clock();
    // pcl::io::savePLYFileBinary(root_path_ + "/cloud_ds.ply", *cloud_filtered);
    // printf("save cloud_ds.ply used time: %0.4lf s\n", (double)(clock() - start_t) / (CLOCKS_PER_SEC));


    // double ds_size = 0.01;
    // pcl::VoxelGrid<pcl::PointXYZRGBL> sor;
    // sor.setInputCloud(cloud);
    // sor.setLeafSize(ds_size, ds_size, ds_size);
    // sor.filter(*cloud_filtered);

    // using pcl's Statistical Outlier Removal filter
    // start = clock();printf("start NOR filter...\n");
    // pcl::StatisticalOutlierRemoval<pcl::PointXYZRGBL> sor;
	// sor.setInputCloud(cloud_filtered);//设置待滤波的点云
	// sor.setMeanK(6);//设置在进行统计时考虑查询点邻居点数
	// sor.setStddevMulThresh(1.0);//设置判断是否为离群点的阈值
	// sor.filter(*cloud_filtered);//将滤波结果保存在cloud_filtered中
    // printf("StatisticalOutlierRemoval to size %d used time: %0.4lf s\n", cloud_filtered->points.size(), (double)(clock() - start) / (CLOCKS_PER_SEC));

    // *cloud_filtered = *cloud;

    // start = clock();
    // pcl::io::savePLYFileBinary(root_path_ + "/cloud_NORfiltered.ply", *cloud_filtered);
    // printf("save cloud_NORfiltered.ply used time: %0.4lf s\n", (double)(clock() - start) / (CLOCKS_PER_SEC));

    // // Output has the PointNormal type in order to store the normals calculated by MLS
    // pcl::PointCloud<pcl::PointXYZRGBL>::Ptr mls_points;
    // // Init object (second point type is for the normals, even if unused)
    // pcl::MovingLeastSquares<pcl::PointXYZRGBL, pcl::PointXYZRGBL> mls;
    // mls.setComputeNormals (true);
    // // Set parameters
    // mls.setInputCloud (cloud_filtered);
    // mls.setPolynomialOrder (2);
    // // Create a KD-Tree
    // pcl::search::KdTree<pcl::PointXYZRGBL>::Ptr tree (new pcl::search::KdTree<pcl::PointXYZRGBL>);
    // mls.setSearchMethod (tree);
    // mls.setSearchRadius (0.05);
    // mls.setNumberOfThreads(8);
    // mls.process (*mls_points);
    // *cloud_filtered = *mls_points;
    // pcl::io::savePCDFile(root_path_ + "/cloud_filtered_offrend_mls.ply", *mls_points);

    // 单独开启线程显示点云
    // std::thread t1(showPointCloud, cloud);
    // t1.detach();

    

    double proj_ang_max = 200. / 180. * 3.1415926;
    timeval time_beg, time_end; 
    gettimeofday(&time_beg, NULL);
    int outlier_num;
    std::vector<bool> effect_pts(cloud_filtered->points.size(), true);
    tbb::parallel_for(tbb::blocked_range<size_t>(0, cloud_filtered->points.size()), [&](const tbb::blocked_range<size_t> &r){
    // for (int i = 0; i < cloud_filtered->points.size(); i ++) 
    for (int i = r.begin(); i!=r.end(); i ++) 
    {
        // if (i % 3 != 1) continue;
        bool dbg_print = (i % 1000000 == 0) ? true : false;
        pcl::PointXYZRGBL & proc_pt = cloud_filtered->points[i];
        std::vector<int> pointIdxRadiusSearch;
        std::vector<float> pointRadiusSquaredDistance;
        float radius = 0.03f;
        // float radiusSquared = radius * radius;
        Eigen::Vector3d pt (proc_pt.x, proc_pt.y, proc_pt.z);
        std::unordered_map<uint32_t, uint32_t>  label_list;
        std::vector<CamPosIndScore> cam_pos_ind_score_list;
        float x_total = 0.0f, y_total = 0.0f, z_total = 0.0f, xyz_score_total = 0.0;
        label_list[proc_pt.label] = proc_pt.label;
        if (kdtree.radiusSearch(proc_pt, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) > 0)
        {
            if (pointIdxRadiusSearch.size() < 2) 
            {
                effect_pts[i] = false;
                // printf("Find Outlier Point! total num %d\n", outlier_num ++);
                continue;
            }

            effect_pts[i] = true;
            for (int j = 0; j < pointIdxRadiusSearch.size(); j ++)
            {
                auto & pt_neighb = cloud_filtered->points[pointIdxRadiusSearch[j]];
                Eigen::Vector3d pt_neighb_vec (pt_neighb.x, pt_neighb.y, pt_neighb.z);
                uint32_t label = pt_neighb.label;
                const Eigen::Matrix4d &  T_imu        = cam_pose[label];
                const Eigen::Vector3d && imu_position = cam_pose[label].block<3, 1>(0, 3);
                double dist_to_imu = (Eigen::Vector3d (pt_neighb.x, pt_neighb.y, pt_neighb.z) - imu_position).norm();
                float xyz_score = 1.0 / abs(dist_to_imu);
                x_total += xyz_score * pt_neighb.x;
                y_total += xyz_score * pt_neighb.y;
                z_total += xyz_score * pt_neighb.z;
                xyz_score_total += xyz_score;
                // printf("pointIdxRadiusSearch[%d] = %d, label: %d, dist: %lf\n", 
                // j, pointIdxRadiusSearch[j], cloud->points[pointIdxRadiusSearch[j]].label, pointRadiusSquaredDistance[j]);
                if (label_list.find(label) == label_list.end())
                {
                    PolyProject polyproj;
                    if (polyproj.check(pt, T_imu, camParams_, proj_ang_max) == false) continue;
                    float rgb_score = 1.0 / abs(dist_to_imu) + 1.0 / 10 * abs(polyproj.get_view_angle());
                    rgb_score *= rgb_score;
                    label_list[label] = label;
                    cam_pos_ind_score_list.push_back(CamPosIndScore(label, rgb_score));
                }
            }

            if (dbg_print)  printf("-- target: %d label_list size: %d\n", i, label_list.size());
        }

        float neight_aver_score = xyz_score_total / pointIdxRadiusSearch.size();
        float proc_pt_score = 1.0 / abs((pt - cam_pose[proc_pt.label].block<3, 1>(0, 3)).norm());
        float a1 = proc_pt_score * 0.5 / (proc_pt_score + neight_aver_score);
        float a2 = 1 - a1;

        proc_pt.x = a1 * proc_pt.x + a2 * (x_total / xyz_score_total);
        proc_pt.y = a1 * proc_pt.y + a2 * (y_total / xyz_score_total);
        proc_pt.z = a1 * proc_pt.z + a2 * (z_total / xyz_score_total);

        // sort cam_pos_ind_score_list based on score from large to small
        std::sort(cam_pos_ind_score_list.begin(), cam_pos_ind_score_list.end(), 
            [](const CamPosIndScore & a, const CamPosIndScore & b) -> bool
            {
                return a.score > b.score;
            }
        );

        uint32_t obs_best_frame_index = 0;
        double obs_best_score = 0.0;
        double total_score = 0.0;
        bool finded_best = false;
        std::vector<double> score_list;score_list.reserve(label_list.size());
        float r_total = 0.0f, g_total = 0.0f, b_total = 0.0f;
        int fusion_num = 0;
        for (auto pos : cam_pos_ind_score_list)
        {
            uint32_t frame_index = pos.cam_pos_ind;
            float score = pos.score;

            total_score += score;
            pcl::PointXYZRGBL reprojected_pt;
            reprojectpt(proc_pt, left_images[frame_index], right_images[frame_index], cam_pose[frame_index], camParams_, reprojected_pt);
            r_total += score * reprojected_pt.r;
            g_total += score * reprojected_pt.g;
            b_total += score * reprojected_pt.b;
            
            if (dbg_print) {
                Eigen::Vector3i rgb (reprojected_pt.r, reprojected_pt.g, reprojected_pt.b);
                Eigen::Vector3f hsv = rgb2hsv(rgb);
                printf("Reproject to %d th frame, get rgb %d %d %d, hsv %f %f %f, score: %lf.\n", frame_index, 
                            reprojected_pt.r, reprojected_pt.g, reprojected_pt.b, hsv[0], hsv[1], hsv[2], score);
                // Eigen::Vector3i rgb2 = hsv2rgb(hsv);
                // printf("HSV Transback rgb: %d %d %d\n", rgb2[0], rgb2[1], rgb2[2]);
            }

            if (score > obs_best_score)
            {
                obs_best_score = score;
                obs_best_frame_index = frame_index;
                finded_best = true;
            }

            fusion_num ++;
            if (fusion_num > 5) break;
            
            // score_list.push_back(score);
        }
        if (!finded_best)  continue;
        if (dbg_print) printf("obs_best_frame_index: %d, best score: %lf\n", obs_best_frame_index, obs_best_score);

        proc_pt.r = r_total / total_score;
        proc_pt.g = g_total / total_score;
        proc_pt.b = b_total / total_score;

        // pcl::PointXYZRGBL reprojected_pt;
        // reprojectpt(proc_pt, left_images[obs_best_frame_index], right_images[obs_best_frame_index], cam_pose[obs_best_frame_index], camParams_, reprojected_pt);
        // total_score = 1.0f;
        // proc_pt = reprojected_pt;
    }
    });

    pcl::PointCloud<pcl::PointXYZRGBL>::Ptr cloud_filtered_rmoutlier(new pcl::PointCloud<pcl::PointXYZRGBL>);
    for (int i = 0; i < cloud_filtered->size(); i ++)
    {
        if (effect_pts[i])  cloud_filtered_rmoutlier->push_back(cloud_filtered->points[i]);
    }
    printf("Outlier size: %d\n", cloud_filtered->size() - cloud_filtered_rmoutlier->size());
    gettimeofday(&time_end, NULL);
    printf("color refine and point smooth takes %.4lf s.\n", (double)(time_end.tv_sec - time_beg.tv_sec + (time_end.tv_usec - time_beg.tv_usec) / 1000000.0));
    // save cloud_filtered to ply file
    pcl::io::savePLYFileBinary(root_path_ + "/cloud_filtered_offrend.ply", *cloud_filtered_rmoutlier);

    showPointCloud(cloud_filtered);

}
