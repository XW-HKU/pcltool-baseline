#ifndef POLY_PROJECTION_H
#define POLY_PROJECTION_H

#include <stdio.h>
#include <iostream>
#include <Eigen/Core>
#include <eigen3/Eigen/Eigen>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <Eigen/Core>

template <typename T> 
struct poly_inner
{
    int width;
    int height;
    Eigen::Matrix<T, 3, 3> innerT;
    Eigen::Matrix<T, 6, 1> distorT;
    poly_inner() {};
    poly_inner(T fx, T fy, T cx, T cy, int w, int h) : width(w), height(h)
    {
        innerT.setZero();
        innerT(0, 0) = fx;
        innerT(1, 1) = fy;
        innerT(0, 2) = cx;
        innerT(1, 2) = cy;
    };
};

template <typename T> 
struct pinhole_simple_inner
{
    int width;
    int height;
    Eigen::Matrix<T, 3, 3> innerT;
    // Eigen::Matrix<T, 6, 1> distorT;
    pinhole_simple_inner(T fx, T fy, T cx, T cy, int w, int h) : width(w), height(h)
    {
        innerT.setZero();
        innerT(0, 0) = fx;
        innerT(1, 1) = fy;
        innerT(0, 2) = cx;
        innerT(1, 2) = cy;
    };
};

template <typename T>
struct poly_ext
{
    Eigen::Matrix<T, 4, 4> Tcl;
};

template <typename T>
struct CamParams
{
    std::vector< poly_inner<T> > inner_list;
    std::vector< poly_ext<T> > ext_list;
};


template <typename T> 
struct Proj2DAng
{
    Eigen::Matrix<T, 2, 1> p_2;
    T theta;
    int Flg;
};

#define OUT_OF_LENS (0)
#define OUT_OF_IMG  (-1)
#define IN_IMG      (1)

// 载入内外参
template <typename T>
void parse_cam_params(const std::string &filename, 
                        std::vector<poly_inner<T>> &int_params_vec, 
                        std::vector<poly_ext<T>> &ext_params_vec)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }

    std::string line;
    poly_inner<T> current_cam;
    poly_ext<T> current_ext;
    Eigen::Matrix<T, 4, 4> Tcl;
    int row = 0;
    bool parsing_cam = false;
    while (std::getline(file, line))
    {
        std::istringstream ss(line);
        std::string key;
        ss >> key;
        if (key == "Tcl_0:" || key == "Tcl_1:")
        {
            if (row > 0)
            {
                current_ext.Tcl = Tcl;
                ext_params_vec.push_back(current_ext);
            }
            Tcl.setZero();
            row = 0;

            // Read the first row of the matrix
            char open_bracket;
            ss >> open_bracket; // Read the opening bracket '['
            for (int c = 0; c < 4; ++c)
            {
                T val;
                ss >> val;
                Tcl(0, c) = val;

                if (c < 3) // Skip the comma after the last element in the row
                {
                    char comma;
                    ss >> comma;
                }
            }
            char close_bracket;
            ss >> close_bracket; // Read the closing bracket ']'

            // Read the next 3 rows of the matrix
            for (int r = 1; r < 4; ++r)
            {
                std::getline(file, line);
                ss = std::istringstream(line);

                for (int c = 0; c < 4; ++c)
                {
                    T val;
                    ss >> val;
                    Tcl(r, c) = val;

                    if (c < 3) // Skip the comma after the last element in the row
                    {
                        char comma;
                        ss >> comma;
                    }
                }
            }

            current_ext.Tcl = Tcl;
            ext_params_vec.push_back(current_ext); // Add the parsed Tcl matrix to ext_params_vec

        // ...
        }
        else if (key == "cam_0:" || key == "cam_1:")
        {
            if (parsing_cam)
            {
                int_params_vec.push_back(current_cam);
            }
            parsing_cam = true;
            current_cam = poly_inner<T>();
            current_cam.innerT.setZero();
            current_cam.innerT(2, 2) = 1;
        }
        else if (key == "image_width:")
        {
            ss >> current_cam.width;
        }
        else if (key == "image_height:")
        {
            ss >> current_cam.height;
        }
        else if (key.substr(0, 2) == "A1" || key.substr(0, 2) == "A2") {
            int r = key[1] - '1';
            int c = key[2] - '1';
            T val;
            ss >> val;
            current_cam.innerT(r, c) = val;
        } else if (key.substr(0, 1) == "u" || key.substr(0, 1) == "v") {
            int r = key[0] == 'u' ? 0 : 1;
            T val;
            ss >> val;
            current_cam.innerT(r, 2) = val;
        } else if (key[0] == 'k') {
            int idx = key[1] - '0';
            T val;
            ss >> val;
            current_cam.distorT(idx - 2, 0) = val;
        }
    }

    if (parsing_cam)
    {
        int_params_vec.push_back(current_cam);
    }
    if (row > 0)
    {
        current_ext.Tcl = Tcl;
        ext_params_vec.push_back(current_ext);
    }

    file.close();
}

class PolyProject
{
    public:
    Proj2DAng<double> p_2DAng_;
    // CamParams<double> camParams_;
    // const double max_ang_;

    PolyProject()
    {
    };

    template <typename T> 
    bool check(const Eigen::Matrix<T, 3, 1> &p_w,
                            const Eigen::Matrix<T, 4, 4> &T_imu, 
                            const CamParams<T> & camParams,
                            const T &max_ang,
                            const int &margin = 0)
    {
        static Eigen::Matrix4d T_i_l = Eigen::Matrix4d::Identity(); 
        T_i_l << 1, 0, 0, -0.011,
                0, 1, 0, -0.02329,
                0, 0, 1, 0.04412,
                0, 0, 0, 1;
        Eigen::Matrix4d T_reverse = (T_imu * T_i_l).inverse();
        Eigen::Matrix<double, 4, 4> T_left = camParams.ext_list[0].Tcl * T_reverse;
        Eigen::Matrix<double, 4, 4> T_right = camParams.ext_list[1].Tcl * T_reverse;
        Proj2DAng<double> p_2DAng;
        // auto T_left = T_imu * camParams.ext_list[0].Tcl;
        int ret1 = point_project(p_w, T_left, camParams.inner_list[0], max_ang, p_2DAng_, 20);
        if (ret1 == IN_IMG) return true;
    
        int ret2 = point_project(p_w, T_right, camParams.inner_list[1], max_ang, p_2DAng_, 20);
        if (ret2 == IN_IMG) return true;

        return false;
    }

    double get_view_angle()
    {
        return p_2DAng_.theta;
    }

    template <typename T> 
    int point_project(  const Eigen::Matrix<T, 3, 1> &p_l,
                                const Eigen::Matrix<T, 4, 4> &T_w_c, 
                                const poly_inner<T> &inner,
                                const T &max_ang,
                                Proj2DAng<T> &p_2DAng,
                                const int & margin = 0)
    {
        Eigen::Matrix<T, 3, 1> p_c = T_w_c.block(0, 0, 3, 3) * p_l + T_w_c.block(0, 3, 3, 1);
        
        p_2DAng.p_2 = Eigen::Matrix<double, 2, 1>::Zero();
        const T theta        = acos( p_c( 2 ) / p_c.norm( ) );
        p_2DAng.theta = theta;
        // cout<<"p_c: "<<p_c.transpose()<<" theta: "<<theta<<endl;
        if (std::abs(theta) > max_ang/2) return OUT_OF_LENS;
        const T inverse_r_P2 = 1.0 / sqrt( p_c( 1 ) * p_c( 1 ) + p_c( 0 ) * p_c( 0 ));
        const T sin_phi      = p_c( 1 ) * inverse_r_P2;
        const T cos_phi      = p_c( 0 ) * inverse_r_P2;

        const T &A11 = inner.innerT.coeffRef(0, 0);
        const T &A12 = inner.innerT.coeffRef(0, 1);
        const T &A22 = inner.innerT.coeffRef(1, 1);
        const T &u0 = inner.innerT.coeffRef(0, 2);
        const T &v0 = inner.innerT.coeffRef(1, 2);
        //k2~k7 is ocamModel.invpol[i]
        const T &k2 = inner.distorT[0];
        const T &k3 = inner.distorT[1];
        const T &k4 = inner.distorT[2];
        const T &k5 = inner.distorT[3];
        const T &k6 = inner.distorT[4];
        const T &k7 = inner.distorT[5];

        Eigen::Matrix<T, 2, 1> p_u;

        T && the2 = theta * theta;
        T && the3 = the2 * theta;
        T && the4 = the3 * theta;
        T && the5 = the4 * theta;
        T && the6 = the5 * theta;
        T && the7 = the6 * theta;

        T r_point = theta
                        + k2 * the2
                        + k3 * the3
                        + k4 * the4
                        + k5 * the5
                        + k6 * the6
                        + k7 * the7;
        //
        p_u = r_point * Eigen::Matrix<T, 2, 1>( cos_phi, sin_phi );
        
        p_2DAng.p_2( 0 ) = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
        p_2DAng.p_2( 1 ) = A22 * p_u( 1 ) + v0;

        if (p_2DAng.p_2(0) < margin || p_2DAng.p_2(1) < margin || p_2DAng.p_2(0) > (inner.width-margin) || p_2DAng.p_2(1) > (inner.height-margin))
        {
            // printf("H V: %d %d \n", inner.width, inner.height);
            return OUT_OF_IMG;
        }

        return IN_IMG;
    }

    template <typename T> 
    int point_project( const Eigen::Matrix<T, 3, 1> &p_l,
                                const Eigen::Quaternion<T> &q,
                                const Eigen::Matrix<T, 3, 1> &t, 
                                const Eigen::Matrix<T, 3, 3> &innerT, 
                                const Eigen::Matrix<T, 6, 1> &distorT,
                                const T &max_ang,
                                Eigen::Matrix<T, 2, 1> &p_2)                 
    {
        Eigen::Matrix<T, 3, 1> p_c = q.toRotationMatrix() * p_l + t;
        p_2 = Eigen::Matrix<T, 2, 1>::Zero();
        const T theta        = acos( p_c( 2 ) / p_c.norm( ) );
        if (std::abs(theta) > max_ang/2) return -1;
        const T inverse_r_P2 = 1.0 / sqrt( p_c( 1 ) * p_c( 1 ) + p_c( 0 ) * p_c( 0 ));
        const T sin_phi      = p_c( 1 ) * inverse_r_P2;
        const T cos_phi      = p_c( 0 ) * inverse_r_P2;

        const T &A11 = innerT.coeffRef(0, 0);
        const T &A12 = innerT.coeffRef(0, 1);
        const T &A22 = innerT.coeffRef(1, 1);
        const T &u0 = innerT.coeffRef(0, 2);
        const T &v0 = innerT.coeffRef(1, 2);
        //k2~k7 is ocamModel.invpol[i]
        const T &k2 = distorT[0];
        const T &k3 = distorT[1];
        const T &k4 = distorT[2];
        const T &k5 = distorT[3];
        const T &k6 = distorT[4];
        const T &k7 = distorT[5];

        Eigen::Matrix<T, 2, 1> p_u;

        T && the2 = theta * theta;
        T && the3 = the2 * theta;
        T && the4 = the3 * theta;
        T && the5 = the4 * theta;
        T && the6 = the5 * theta;
        T && the7 = the6 * theta;
        

        T r_point = theta
                        + k2 * the2
                        + k3 * the3
                        + k4 * the4
                        + k5 * the5
                        + k6 * the6
                        + k7 * the7;
        //
        p_u = r_point * Eigen::Matrix<T, 2, 1>( cos_phi, sin_phi );
        
        p_2( 0 ) = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
        p_2( 1 ) = A22 * p_u( 1 ) + v0;
        return 1;
    }

    // template <typename T> 
    // void point_project( const cv::Point3_<T> & P3Point,
    //                         const Eigen::Matrix<T, 3, 3> & R_p,
    //                         const Eigen::Matrix<T, 3, 1> & T_p,
    //                         const Eigen::Matrix<T, 3, 3> &innerT, 
    //                         const Eigen::Matrix<T, 6, 1> &distorT,
    //                         cv::Point_<T> & P2Point )
    // {
    //     Eigen::Matrix4d T_c_l = Eigen::Matrix4d::Identity();
    //     T_c_l.block<3,3>(0,0) = R_p;
    //     T_c_l.block<3,1>(0,3) = T_p;

    //     const T &A11 = innerT.coeffRef(0, 0);
    //     const T &A12 = innerT.coeffRef(0, 1);
    //     const T &A22 = innerT.coeffRef(1, 1);
    //     const T &u0 = innerT.coeffRef(0, 2);
    //     const T &v0 = innerT.coeffRef(1, 2);
        
    //     const T &k2 = distorT[0];
    //     const T &k3 = distorT[1];
    //     const T &k4 = distorT[2];
    //     const T &k5 = distorT[3];
    //     const T &k6 = distorT[4];
    //     const T &k7 = distorT[5];

    //     Eigen::Matrix<T, 4, 1> Pt4(P3Point.x, P3Point.y, P3Point.z, 1);
    //     Eigen::Matrix<T, 4, 1> Pt4_t = T_c_l * Pt4;
    //     Eigen::Matrix<T, 3, 1> Pt(Pt4_t(0), Pt4_t(1), Pt4_t(2));

    //     T theta = acos( Pt( 2 ) / Pt.norm( ) );
    //     T inverse_r_P2 = 1.0 / sqrt( Pt4_t( 1 ) * Pt4_t( 1 ) + Pt4_t( 0 ) * Pt4_t( 0 ) );
    //     T sin_phi      = Pt4_t( 1 ) * inverse_r_P2;
    //     T cos_phi      = Pt4_t( 0 ) * inverse_r_P2;

    //     Eigen::Matrix<T, 2, 1> p_u;
    //     cv::Point_<T> p;
        
    //     if( k2 != 0.0 )
    //     {
    //         double && the2 = theta * theta;
    //         double && the3 = the2 * theta;
    //         double && the4 = the3 * theta;
    //         double && the5 = the4 * theta;
    //         double && the6 = the5 * theta;
    //         double && the7 = the6 * theta;  

    //         double r_point = theta
    //                         + k2 * the2
    //                         + k3 * the3
    //                         + k4 * the4
    //                         + k5 * the5
    //                         + k6 * the6
    //                         + k7 * the7;

    //         p_u = r_point * Eigen::Vector2d( cos_phi, sin_phi );
    //         p.x = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
    //         p.y = A22 * p_u( 1 ) + v0;
    //         P2Point = p;
    //     }
    //     else
    //     {
    //         p.x = A11 * theta * cos_phi + u0;
    //         p.y = A22 * theta * cos_phi + v0;
    //         // P2List.push_back(p);
    //         P2Point = p;
    //     }
    // }

    // template <typename T> 
    // void poly_list_projection( const std::vector<cv::Point3_<T>> & P3List,
    //                         const Eigen::Matrix<T, 4, 4> & Trans,
    //                         const Eigen::Matrix<T, 3, 3> &innerT, 
    //                         const Eigen::Matrix<T, 6, 1> &distorT,
    //                         std::vector<cv::Point_<T>> & P2List )
    // {
    //     P2List.clear();
    //     P2List.reserve(P3List.size());

    //     const T &A11 = innerT.coeffRef(0, 0);
    //     const T &A12 = innerT.coeffRef(0, 1);
    //     const T &A22 = innerT.coeffRef(1, 1);
    //     const T &u0 = innerT.coeffRef(0, 2);
    //     const T &v0 = innerT.coeffRef(1, 2);
        
    //     const T &k2 = distorT[0];
    //     const T &k3 = distorT[1];
    //     const T &k4 = distorT[2];
    //     const T &k5 = distorT[3];
    //     const T &k6 = distorT[4];
    //     const T &k7 = distorT[5];

    //     for( auto P : P3List )
    //     {
    //         Eigen::Matrix<T, 4, 1> Pt4(P.x, P.y, P.z, 1);
    //         Eigen::Matrix<T, 4, 1> Pt4_t = Trans * Pt4;
    //         Eigen::Matrix<T, 3, 1> Pt(Pt4_t(0), Pt4_t(1), Pt4_t(2));

    //         T theta = acos( Pt( 2 ) / Pt.norm( ) );
    //         //    double phi   = atan2(P(1), P(0));
    //         T inverse_r_P2 = 1.0 / sqrt( Pt4_t( 1 ) * Pt4_t( 1 ) + Pt4_t( 0 ) * Pt4_t( 0 ) );
    //         T sin_phi      = Pt4_t( 1 ) * inverse_r_P2;
    //         T cos_phi      = Pt4_t( 0 ) * inverse_r_P2;

    //         Eigen::Matrix<T, 2, 1> p_u;
    //         cv::Point_<T> p;

    //         if ( k2 != 0.0 )
    //       {
    //         double && the2 = theta * theta;
    //         double && the3 = the2 * theta;
    //         double && the4 = the3 * theta;
    //         double && the5 = the4 * theta;
    //         double && the6 = the5 * theta;
    //         double && the7 = the6 * theta;

    //         double r_point = theta
    //                         + k2 * the2
    //                         + k3 * the3
    //                         + k4 * the4
    //                         + k5 * the5
    //                         + k6 * the6
    //                         + k7 * the7;

    //         p_u = r_point * Eigen::Vector2d( cos_phi, sin_phi );

    //         p.x = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
    //         p.y = A22 * p_u( 1 ) + v0;
    //         P2List.push_back(p);
    //       }
    //       else
    //       {
    //         p.x = A11 * theta * cos_phi + u0;
    //         p.y = A22 * theta * cos_phi + v0;
    //         P2List.push_back(p);
    //       }
    //     }
    // }

    // template <typename T> 
    // void poly_list_projection( const std::vector<cv::Point3_<T>> & P3List,
    //                         const Eigen::Matrix<T, 3, 3> & R_p,
    //                         const Eigen::Matrix<T, 3, 1> & T_p,
    //                         const Eigen::Matrix<T, 3, 3> &innerT, 
    //                         const Eigen::Matrix<T, 6, 1> &distorT,
    //                         std::vector<cv::Point_<T>> & P2List )
    // {
    //     Eigen::Matrix4d T_c_l = Eigen::Matrix4d::Identity();
    //     T_c_l.block<3,3>(0,0) = R_p;
    //     T_c_l.block<3,1>(0,3) = T_p;
        

    //     P2List.clear();
    //     P2List.reserve(P3List.size());

    //     const T &A11 = innerT.coeffRef(0, 0);
    //     const T &A12 = innerT.coeffRef(0, 1);
    //     const T &A22 = innerT.coeffRef(1, 1);
    //     const T &u0 = innerT.coeffRef(0, 2);
    //     const T &v0 = innerT.coeffRef(1, 2);
        
    //     const T &k2 = distorT[0];
    //     const T &k3 = distorT[1];
    //     const T &k4 = distorT[2];
    //     const T &k5 = distorT[3];
    //     const T &k6 = distorT[4];
    //     const T &k7 = distorT[5];
        
    //     for( auto P : P3List )
    //     {
    //         Eigen::Matrix<T, 4, 1> Pt4(P.x, P.y, P.z, 1);
    //         Eigen::Matrix<T, 4, 1> Pt4_t = T_c_l * Pt4;
    //         Eigen::Matrix<T, 3, 1> Pt(Pt4_t(0), Pt4_t(1), Pt4_t(2));

    //         T theta = acos( Pt( 2 ) / Pt.norm( ) );
    //         T inverse_r_P2 = 1.0 / sqrt( Pt4_t( 1 ) * Pt4_t( 1 ) + Pt4_t( 0 ) * Pt4_t( 0 ) );
    //         T sin_phi      = Pt4_t( 1 ) * inverse_r_P2;
    //         T cos_phi      = Pt4_t( 0 ) * inverse_r_P2;

    //         Eigen::Matrix<T, 2, 1> p_u;
    //         cv::Point_<T> p;
            
    //         if( k2 != 0.0 )
    //         {
    //             double && the2 = theta * theta;
    //         double && the3 = the2 * theta;
    //         double && the4 = the3 * theta;
    //         double && the5 = the4 * theta;
    //         double && the6 = the5 * theta;
    //         double && the7 = the6 * theta;  

    //         double r_point = theta
    //                         + k2 * the2
    //                         + k3 * the3
    //                         + k4 * the4
    //                         + k5 * the5
    //                         + k6 * the6
    //                         + k7 * the7;

    //         p_u = r_point * Eigen::Vector2d( cos_phi, sin_phi );
    //         p.x = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
    //         p.y = A22 * p_u( 1 ) + v0;
    //         P2List.push_back(p);
    //         }
    //         else
    //         {
    //             p.x = A11 * theta * cos_phi + u0;
    //             p.y = A22 * theta * cos_phi + v0;
    //             P2List.push_back(p);
    //         }
    //     }
    // }

    // template <typename T>
    // void mei_list_projection(const std::vector<cv::Point3_<T>> & P3List,
    //                     const Eigen::Matrix<T, 3, 3> & R_m,
    //                     const Eigen::Matrix<T, 3, 1> & T_m,
    //                     const Eigen::Matrix<T, 3, 3> &innerT,
    //                     const Eigen::Matrix<T, 5, 1> &distorT,
    //                     std::vector<cv::Point_<T>> &P2List)
    // {
    //     Eigen::Matrix4d T_c_l = Eigen::Matrix4d::Identity();
    //     T_c_l.block<3,3>(0,0) = R_m;
    //     T_c_l.block<3,1>(0,3) = T_m;
        
    //     P2List.clear();
    //     P2List.reserve(P3List.size());

    //     T xi = distorT[2];

    //     T k1 = distorT[0];
    //     T k2 = distorT[1];
    //     T p1 = distorT[3];
    //     T p2 = distorT[4];

    //     T gamma1 = innerT.coeffRef(0, 0);
    //     T gamma2 = innerT.coeffRef(1, 1);
    //     T u0     = innerT.coeffRef(0, 2);
    //     T v0     = innerT.coeffRef(1, 2);

    //     for (auto P : P3List)
    //     {
    //         Eigen::Matrix<T, 2, 1> p_u, p_d;
    //         Eigen::Matrix<T, 4, 1> pt4(P.x, P.y, P.z, 1);
    //         Eigen::Matrix<T, 4, 1> pt4_t = T_c_l * pt4;
    //         Eigen::Matrix<T, 3, 1> Pt(pt4_t(0), pt4_t(1), pt4_t(2));
    //         T z = pt4_t(2) + xi * Pt.norm( );
    //         p_u << pt4_t(0) / z, pt4_t(1) / z;

    //         Eigen::Matrix<T, 2, 1> d_u;
    //         T mx2_u, my2_u, mxy_u, rho2_u, rad_dist_u;

    //         mx2_u      = p_u( 0 ) * p_u( 0 );
    //         my2_u      = p_u( 1 ) * p_u( 1 );
    //         mxy_u      = p_u( 0 ) * p_u( 1 );
    //         rho2_u     = mx2_u + my2_u;
    //         rad_dist_u = k1 * rho2_u + k2 * rho2_u * rho2_u;
    //         d_u << p_u( 0 ) * rad_dist_u + 2.0 * p1 * mxy_u + p2 * ( rho2_u + 2.0 * mx2_u ),
    //         p_u( 1 ) * rad_dist_u + 2.0 * p2 * mxy_u + p1 * ( rho2_u + 2.0 * my2_u );
    //         p_d = p_u + d_u;

    //         cv::Point_<T> p;
    //         p.x = gamma1 * p_d( 0 ) + u0;
    //         p.y = gamma2 * p_d( 1 ) + v0;
    //         P2List.push_back(p);
    //     }
    // }

    template <typename T>
    void mei_point_projection(const Eigen::Matrix<T, 3, 1> &p_l,
                                const Eigen::Quaternion<T> &q,
                                const Eigen::Matrix<T, 3, 1> &t, 
                                const Eigen::Matrix<T, 3, 3> &innerT, 
                                const Eigen::Matrix<T, 6, 1> &distorT,
                                Eigen::Matrix<T, 3, 1> &p_2)
    {
        Eigen::Matrix<T, 3, 1> p_c = q.toRotationMatrix() * p_l + t;

        T xi = distorT[2];

        T k1 = distorT[0];
        T k2 = distorT[1];
        T p1 = distorT[3];
        T p2 = distorT[4];

        T gamma1 = innerT.coeffRef(0, 0);
        T gamma2 = innerT.coeffRef(1, 1);
        T u0     = innerT.coeffRef(0, 2);
        T v0     = innerT.coeffRef(1, 2);

        Eigen::Matrix<T, 2, 1> p_u, p_d;
        T z = p_c(2) + xi * p_c.norm( );
        p_u << p_c(0) / z, p_c(1) / z;

        Eigen::Matrix<T, 2, 1> d_u;
        T mx2_u, my2_u, mxy_u, rho2_u, rad_dist_u;
        
        mx2_u      = p_u( 0 ) * p_u( 0 );
        my2_u      = p_u( 1 ) * p_u( 1 );
        mxy_u      = p_u( 0 ) * p_u( 1 );
        rho2_u     = mx2_u + my2_u;
        rad_dist_u = k1 * rho2_u + k2 * rho2_u * rho2_u;
        d_u << p_u( 0 ) * rad_dist_u + 2.0 * p1 * mxy_u + p2 * ( rho2_u + 2.0 * mx2_u ),
            p_u( 1 ) * rad_dist_u + 2.0 * p2 * mxy_u + p1 * ( rho2_u + 2.0 * my2_u );
        p_d = p_u + d_u;

        p_2.x() = gamma1 * p_d( 0 ) + u0;
        p_2.y() = gamma2 * p_d( 1 ) + v0;
    }

    template <typename T> 
    Eigen::Matrix<T, 2, 1> poly_world2camera( const Eigen::Matrix<T, 3, 1> &p_l,
                                const Eigen::Quaternion<T> &q,
                                const Eigen::Matrix<T, 3, 1> &t, 
                                const Eigen::Matrix<T, 3, 3> &innerT, 
                                const Eigen::Matrix<T, 6, 1> &distorT)                 
    {
        Eigen::Matrix<T, 3, 1> &p_2;

        Eigen::Matrix<T, 3, 1> p_c = q.toRotationMatrix() * p_l + t;

        const T &A11 = innerT.coeffRef(0, 0);
        const T &A12 = innerT.coeffRef(0, 1);
        const T &A22 = innerT.coeffRef(1, 1);
        const T &u0 = innerT.coeffRef(0, 2);
        const T &v0 = innerT.coeffRef(1, 2);
        //k2~k7 is ocamModel.invpol[i]
        const T &k2 = distorT[0];
        const T &k3 = distorT[1];
        const T &k4 = distorT[2];
        const T &k5 = distorT[3];
        const T &k6 = distorT[4];
        const T &k7 = distorT[5];

        const T theta        = acos( p_c( 2 ) / p_c.norm( ) );
        const T inverse_r_P2 = 1.0 / sqrt( p_c( 1 ) * p_c( 1 ) + p_c( 0 ) * p_c( 0 ));
        const T sin_phi      = p_c( 1 ) * inverse_r_P2;
        const T cos_phi      = p_c( 0 ) * inverse_r_P2;

        Eigen::Matrix<T, 2, 1> p_u;

        T && the2 = theta * theta;
        T && the3 = the2 * theta;
        T && the4 = the3 * theta;
        T && the5 = the4 * theta;
        T && the6 = the5 * theta;
        T && the7 = the6 * theta;
        

        T r_point = theta
                        + k2 * the2
                        + k3 * the3
                        + k4 * the4
                        + k5 * the5
                        + k6 * the6
                        + k7 * the7;
        p_u = r_point * Eigen::Matrix<T, 2, 1>( cos_phi, sin_phi );
        
        p_2( 0 ) = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
        p_2( 1 ) = A22 * p_u( 1 ) + v0;

        return p_2;

    }

    template <typename T> 
    Eigen::Matrix<T, 2, 1> poly_world2camera( const Eigen::Matrix<T, 3, 1> & p_l,
                            const Eigen::Matrix<T, 3, 3> & R_p,
                            const Eigen::Matrix<T, 3, 1> & T_p,
                            const Eigen::Matrix<T, 3, 3> &innerT, 
                            const Eigen::Matrix<T, 6, 1> &distorT)
    {
        Eigen::Matrix4d T_c_l = Eigen::Matrix4d::Identity();
        T_c_l.block<3,3>(0,0) = R_p;
        T_c_l.block<3,1>(0,3) = T_p;


        const T &A11 = innerT.coeffRef(0, 0);
        const T &A12 = innerT.coeffRef(0, 1);
        const T &A22 = innerT.coeffRef(1, 1);
        const T &u0 = innerT.coeffRef(0, 2);
        const T &v0 = innerT.coeffRef(1, 2);
        
        const T &k2 = distorT[0];
        const T &k3 = distorT[1];
        const T &k4 = distorT[2];
        const T &k5 = distorT[3];
        const T &k6 = distorT[4];
        const T &k7 = distorT[5];

        Eigen::Matrix<T, 4, 1> Pt4(p_l.x, p_l.y, p_l.z, 1);
        Eigen::Matrix<T, 4, 1> Pt4_t = T_c_l * Pt4;
        Eigen::Matrix<T, 3, 1> Pt(Pt4_t(0), Pt4_t(1), Pt4_t(2));

        T theta = acos( Pt( 2 ) / Pt.norm( ) );
        T inverse_r_P2 = 1.0 / sqrt( Pt4_t( 1 ) * Pt4_t( 1 ) + Pt4_t( 0 ) * Pt4_t( 0 ) );
        T sin_phi      = Pt4_t( 1 ) * inverse_r_P2;
        T cos_phi      = Pt4_t( 0 ) * inverse_r_P2;

        Eigen::Matrix<T, 2, 1> p_u;
        Eigen::Matrix<T, 2, 1> p_c;
        
        if( k2 != 0.0 )
        {
            double && the2 = theta * theta;
            double && the3 = the2 * theta;
            double && the4 = the3 * theta;
            double && the5 = the4 * theta;
            double && the6 = the5 * theta;
            double && the7 = the6 * theta;  

            double r_point = theta
                            + k2 * the2
                            + k3 * the3
                            + k4 * the4
                            + k5 * the5
                            + k6 * the6
                            + k7 * the7;

            p_u = r_point * Eigen::Vector2d( cos_phi, sin_phi );
            p_c( 0 ) = A11 * p_u( 0 ) + A12 * p_u( 1 ) + u0;
            p_c( 1 ) = A22 * p_u( 1 ) + v0;
        }
        else
        {
            p_c( 0 ) = A11 * theta * cos_phi + u0;
            p_c( 1 ) = A22 * theta * cos_phi + v0;
        }
        return p_c;
    }
};



#endif