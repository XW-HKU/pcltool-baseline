# generate the data for 3DGS training based on the scan data from mindpalace:

# make command：


mkdir build

cmake .. && make

# run command:

./build/nerf_run xxxx/xxxx/MTxxxx.lx 1 0.02  // 1是默认参数，0.02是分辨率


成功执行完以上命令后会在MTxxxx.lx同级目录下生成colmap文件夹，内含去畸变照片和点云
